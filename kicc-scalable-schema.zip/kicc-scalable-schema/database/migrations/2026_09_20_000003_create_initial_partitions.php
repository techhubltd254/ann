<?php

/*
|--------------------------------------------------------------------------
| KICC scalable schema (3/3): initial monthly partitions + DEFAULT safety nets
|--------------------------------------------------------------------------
| PostgreSQL 16 / Laravel Serverless Postgres (Neon). Partition DDL is
| executed via DB::statement (Laravel's Schema builder has no partition API).
| Idempotent: CREATE TABLE IF NOT EXISTS everywhere.
*/

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement(<<<'SQL'
DO $$
DECLARE
  t text;
  m text;
BEGIN
  FOR t IN SELECT unnest(ARRAY['orders','ledger_transactions','ledger_entries','pool_contributions','pipeline_events']) LOOP
    FOR m IN SELECT unnest(ARRAY['2026-09-01|2026-10-01|2026_09','2026-10-01|2026-11-01|2026_10','2026-11-01|2026-12-01|2026_11']) LOOP
      EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)',
        t || '_' || split_part(m, '|', 3), t, split_part(m, '|', 1), split_part(m, '|', 2));
    END LOOP;
    EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %I DEFAULT', t || '_default', t);
  END LOOP;
END $$;
SQL);
    }

    public function down(): void
    {
        // Intentionally conservative: partitioned financial tables are never
        // dropped automatically. See DEPLOYMENT_RUNBOOK.md rollback tree.
    }
};
