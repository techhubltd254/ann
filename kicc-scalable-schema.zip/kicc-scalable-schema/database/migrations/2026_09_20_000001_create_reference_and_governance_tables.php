<?php

/*
|--------------------------------------------------------------------------
| KICC scalable schema (1/3): reference + governance tables + hot partitioned tables
|--------------------------------------------------------------------------
| KICC scalable schema for all 152 subsector pipelines.
| PostgreSQL 16 / Laravel Serverless Postgres (Neon). Partition DDL is
| executed via DB::statement (Laravel's Schema builder has no partition API).
| Idempotent: CREATE TABLE IF NOT EXISTS everywhere.
*/

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement(<<<'SQL'
            -- ============================================================================
            -- KICC SCALABLE SCHEMA — PostgreSQL 16 (Laravel Serverless Postgres / Neon)
            -- One polymorphic pipeline core keyed by subsectors (152 reference rows).
            -- Design rules: multi-tenant, partitioned hot tables, JSONB for per-subsector
            -- variation, FK integrity to the subsector registry, zero 152-table sprawl.
            -- Generated 2026-09-20 from config/kicc/subsectors/index.php (152 entries).
            -- ============================================================================
            
            BEGIN;
            
            -- ---------------------------------------------------------------------------
            -- REFERENCE + GOVERNANCE TABLES (unpartitioned, small, high read amplification)
            -- ---------------------------------------------------------------------------
            
            CREATE TABLE IF NOT EXISTS tenants (
              id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
              name          text NOT NULL,
              type          text NOT NULL CHECK (type IN ('county','enterprise','merchant','diaspora','institution')),
              county_id     bigint,
              quadrant      text NOT NULL DEFAULT 'growth' CHECK (quadrant IN ('engine','growth','priority','anchor')),
              status        text NOT NULL DEFAULT 'active',
              meta          jsonb,
              created_at    timestamptz NOT NULL DEFAULT now(),
              updated_at    timestamptz NOT NULL DEFAULT now()
            );
            
            CREATE TABLE IF NOT EXISTS subsectors (
              code             text PRIMARY KEY,              -- 'C1.1' … 'P1.3' (152 rows)
              parent           text NOT NULL,                 -- 'C1' (50 parents)
              sector           text NOT NULL,                 -- 'tourism' … (12 sectors)
              subsector        text NOT NULL,
              slug             text NOT NULL,
              phase            text NOT NULL,
              status           text NOT NULL,
              economics        jsonb NOT NULL,                -- {model, take_rate_pct | flat_fee_kes | rate_note}
              regulators       jsonb NOT NULL DEFAULT '[]',
              tables           jsonb NOT NULL DEFAULT '[]',
              kill_criteria    jsonb NOT NULL DEFAULT '{}',
              earning_locked   boolean NOT NULL DEFAULT false,
              updated_at       timestamptz NOT NULL DEFAULT now()
            );
            
            CREATE TABLE IF NOT EXISTS county_classifications (
              county_id     bigint PRIMARY KEY,
              rps_score     numeric(6,2) NOT NULL DEFAULT 0,
              fns_score     numeric(6,2) NOT NULL DEFAULT 0,
              quadrant      text NOT NULL CHECK (quadrant IN ('engine','growth','priority','anchor')),
              effective_from date,
              updated_at    timestamptz NOT NULL DEFAULT now()
            );
            
            CREATE TABLE IF NOT EXISTS mother_pools (
              id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
              name                text NOT NULL,
              county_id           bigint,
              period_start        date NOT NULL,
              period_end          date NOT NULL,
              total_collected     numeric(18,2) NOT NULL DEFAULT 0,
              holdback_amount     numeric(18,2) NOT NULL DEFAULT 0,
              equalisation_amount numeric(18,2) NOT NULL DEFAULT 0,
              distribution_status text NOT NULL DEFAULT 'open',
              distributed_at      timestamptz,
              created_at          timestamptz NOT NULL DEFAULT now(),
              updated_at          timestamptz NOT NULL DEFAULT now()
            );
            
            CREATE TABLE IF NOT EXISTS joiner_batches (
              id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
              batch_id        text NOT NULL UNIQUE,           -- 'JPB-YYYYMMDD-<hash>' idempotency anchor
              mode            text NOT NULL DEFAULT 'dry_run',
              sector_filter   text,
              totals          jsonb,
              variance_report jsonb,
              status          text NOT NULL DEFAULT 'balanced',
              created_at      timestamptz NOT NULL DEFAULT now()
            );
            
            -- ---------------------------------------------------------------------------
            -- PIPELINE ACTIVATIONS — one row per (tenant, subsector); the cardinality
            -- guarantee the joiner and pool math rely on.
            -- ---------------------------------------------------------------------------
            
            CREATE TABLE IF NOT EXISTS pipelines (
              id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
              tenant_id       bigint NOT NULL REFERENCES tenants(id),
              subsector_code  text NOT NULL REFERENCES subsectors(code),
              status          text NOT NULL DEFAULT 'registered',
              config          jsonb,
              activated_at    timestamptz,
              created_at      timestamptz NOT NULL DEFAULT now(),
              updated_at      timestamptz NOT NULL DEFAULT now(),
              CONSTRAINT pipelines_tenant_subsector_uq UNIQUE (tenant_id, subsector_code)
            );
            
            -- ---------------------------------------------------------------------------
            -- HOT TRANSACTIONAL TABLES — declarative RANGE partitions on created_at.
            -- Unique constraints include the partition key (Postgres rule); global
            -- uniqueness for posting_key is enforced via (posting_key, created_at) plus
            -- the joiner_batches idempotency anchor.
            -- ---------------------------------------------------------------------------
            
            CREATE TABLE IF NOT EXISTS orders (
              id              bigint GENERATED ALWAYS AS IDENTITY,
              tenant_id       bigint NOT NULL,
              subsector_code  text NOT NULL,
              county_id       bigint,
              gmv             numeric(18,2) NOT NULL DEFAULT 0,
              fee             numeric(18,2) NOT NULL DEFAULT 0,
              status          text NOT NULL DEFAULT 'pending',
              meta            jsonb,
              created_at      timestamptz NOT NULL DEFAULT now(),
              PRIMARY KEY (id, created_at)
            ) PARTITION BY RANGE (created_at);
            
            CREATE TABLE IF NOT EXISTS ledger_transactions (
              id               bigint GENERATED ALWAYS AS IDENTITY,
              uuid             uuid NOT NULL DEFAULT gen_random_uuid(),
              tenant_id        bigint,
              subsector_code   text NOT NULL,
              type             text NOT NULL DEFAULT 'hold',
              amount           numeric(18,2) NOT NULL DEFAULT 0,
              status           text NOT NULL DEFAULT 'pending',
              reference_type   text,
              reference_id     bigint,
              created_at       timestamptz NOT NULL DEFAULT now(),
              PRIMARY KEY (id, created_at)
            ) PARTITION BY RANGE (created_at);
            
            CREATE TABLE IF NOT EXISTS ledger_entries (
              id              bigint GENERATED ALWAYS AS IDENTITY,
              posting_key     text NOT NULL,                  -- 'JPB-…:C1.1:seq' from the joiner
              tenant_id       bigint,
              subsector_code  text NOT NULL,
              gl_account      text NOT NULL,
              debit           numeric(18,2) NOT NULL DEFAULT 0,
              credit          numeric(18,2) NOT NULL DEFAULT 0,
              created_at      timestamptz NOT NULL DEFAULT now(),
              PRIMARY KEY (id, created_at)
            ) PARTITION BY RANGE (created_at);
            
            CREATE TABLE IF NOT EXISTS pool_contributions (
              id               bigint GENERATED ALWAYS AS IDENTITY,
              mother_pool_id   bigint NOT NULL,
              subsector_code   text NOT NULL,
              tenant_id        bigint,
              county_id        bigint,
              gmv              numeric(18,2) NOT NULL DEFAULT 0,
              fee              numeric(18,2) NOT NULL DEFAULT 0,
              holdback         numeric(18,2) NOT NULL DEFAULT 0,
              equalisation     numeric(18,2) NOT NULL DEFAULT 0,
              kicc_net         numeric(18,2) NOT NULL DEFAULT 0,
              vendor_payout    numeric(18,2) NOT NULL DEFAULT 0,
              quality_multiplier numeric(5,2) NOT NULL DEFAULT 1.0,
              created_at       timestamptz NOT NULL DEFAULT now(),
              PRIMARY KEY (id, created_at)
            ) PARTITION BY RANGE (created_at);
            
            CREATE TABLE IF NOT EXISTS pipeline_events (
              id              bigint GENERATED ALWAYS AS IDENTITY,
              subsector_code  text NOT NULL,
              event_type      text NOT NULL,
              tenant_id       bigint,
              payload         jsonb,
              created_at      timestamptz NOT NULL DEFAULT now(),
              PRIMARY KEY (id, created_at)
            ) PARTITION BY RANGE (created_at);
            
            -- integrity: every transactional row must reference the real 152-entry registry
            ALTER TABLE orders               ADD CONSTRAINT orders_subsector_fk      FOREIGN KEY (subsector_code) REFERENCES subsectors(code);
            ALTER TABLE ledger_transactions  ADD CONSTRAINT ltx_subsector_fk         FOREIGN KEY (subsector_code) REFERENCES subsectors(code);
            ALTER TABLE ledger_entries       ADD CONSTRAINT lentry_subsector_fk      FOREIGN KEY (subsector_code) REFERENCES subsectors(code);
            ALTER TABLE pool_contributions   ADD CONSTRAINT pool_subsector_fk        FOREIGN KEY (subsector_code) REFERENCES subsectors(code);
            ALTER TABLE pipeline_events      ADD CONSTRAINT pevent_subsector_fk      FOREIGN KEY (subsector_code) REFERENCES subsectors(code);
            
            COMMIT;
        SQL);
    }

    public function down(): void
    {
        // Intentionally conservative: partitioned financial tables are never
        // dropped automatically. See DEPLOYMENT_RUNBOOK.md rollback tree.
    }
};
