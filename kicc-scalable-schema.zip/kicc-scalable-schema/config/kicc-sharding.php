<?php

/* Shard routing config — dormant at Level 0/1/2 (see SCHEMA_SHARDING.md).
 * Activate Level 3 only when primary saturation metrics (§5) fire. */

return [
    'primary_connection' => 'pgsql',
    'default_connection' => 'pgsql',
    // tenant_id range => connection name (fill when shards are provisioned)
    'tenant_map' => [
        // '1-10000' => 'pgsql_shard_a',
        // '10001-20000' => 'pgsql_shard_b',
    ],
];
