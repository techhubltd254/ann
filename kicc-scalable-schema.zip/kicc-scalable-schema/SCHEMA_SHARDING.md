# KICC Scalable Schema & Sharding Plan — 152 Subsector Pipelines on Laravel Cloud

Generated 2026-09-20. Verified against the live kit registry (152 subsector entries:
trade 22, agriculture 20, tourism 15, investment 15, education 15, energy 13, government 14,
financing 12, mobility 9, health 8, creative 6, identity 3; economics models: 85 commission /
38 flat_fee / 29 rate_note; statuses: 113 absent, 16 licence_gated, 12 partial, 5 blocked, 6 built).

## 0. Design thesis

**One polymorphic pipeline core keyed by a 152-row `subsectors` reference table — NOT 152
duplicated table sets.** The kit's existing per-pipeline tables (115, from the v2–v4 modules)
remain the sector-specific detail layer; this schema adds the shared transactional core that
scales: every money-moving row carries `subsector_code` as an FK to the registry, so the
joiner, Mother-Pool, and trial balance operate over ONE index structure instead of 152.

## 1. Platform facts (verified, not assumed)

- Laravel Cloud offers first-party **Laravel MySQL** (proxy layer multiplexes read-only
  queries, up to ~10,000 connections) and **Laravel Serverless Postgres** powered by Neon
  (pgbouncer connection pooling, ~10,000 concurrent connections, scale-to-zero, point-in-time
  recovery). Sources: laravel.com/cloud/docs/resources/databases/laravel-mysql and
  laravel.com/cloud/docs/resources/databases/postgres.
- The kit's DDL targets **PostgreSQL 16** (declarative partitioning + INCLUDE indexes + GIN
  jsonb_path_ops). On Laravel MySQL or your current TiDB, §6 gives the equivalent plan
  (TiDB: RANGE/HASH/KEY partitioning supported, max 1024 partitions per table, automatic
  ~256MB region sharding across TiKV — docs.pingcap.com/tidb/stable/partitioned-table).

## 2. Tables (11 total: 6 reference/governance + 5 partitioned hot tables)

| Table | Kind | Partitioning | Purpose |
|---|---|---|---|
| `tenants` | reference | none | counties / enterprises / merchants / diaspora / institutions |
| `subsectors` | reference (152 rows, seeded from kit config) | none | THE registry: code, parent, sector, phase, status, economics JSONB, earning_locked |
| `pipelines` | activation | none | one row per (tenant, subsector) — UNIQUE constraint = joiner cardinality guarantee |
| `county_classifications` | governance | none | RPS/FNS → quadrant per county |
| `mother_pools` | governance | none | pool headers, totals, distribution status |
| `joiner_batches` | governance | none | batch_id idempotency anchor + variance reports |
| `orders` | **hot** | RANGE (created_at), monthly | polymorphic order rows for all 152 subsectors; `meta` JSONB absorbs subsector-specific fields |
| `ledger_transactions` | **hot** | RANGE (created_at), monthly | escrow lifecycle rows (hold/capture/split/release/refund) |
| `ledger_entries` | **hot** | RANGE (created_at), monthly | double-entry journal lines with `posting_key` |
| `pool_contributions` | **hot** | RANGE (created_at), monthly | Mother-Pool contributions (gmv/fee/holdback/equalisation/kicc_net/vendor_payout) |
| `pipeline_events` | **hot** | RANGE (created_at), monthly | audit trail, payload JSONB |

## 3. Index plan (16 indexes, each tied to a query pattern)

| # | Index | Query pattern it serves |
|---|---|---|
| 1 | `orders (subsector_code, created_at)` | joiner per-pipeline monthly GMV rollup |
| 2 | `orders (county_id, created_at)` | county attribution + dashboards |
| 3 | `orders (tenant_id, created_at)` | tenant account history |
| 4 | `orders (subsector_code, created_at) WHERE status='pending'` | partial — pending-work queue scan |
| 5 | `orders USING gin (meta jsonb_path_ops)` | ad-hoc subsector-specific attribute search |
| 6 | `ledger_transactions (subsector_code, created_at)` | per-pipeline money lifecycle |
| 7 | `ledger_transactions (uuid)` | batch reconciliation lookup |
| 8 | `ledger_entries (gl_account, created_at) INCLUDE (debit, credit)` | **covering** trial-balance scan — index-only, no heap |
| 9 | `ledger_entries (posting_key)` | idempotency re-check |
| 10 | `pool_contributions (mother_pool_id, subsector_code)` | distribution computation |
| 11 | `pool_contributions (county_id, created_at)` | equalisation/equity reporting |
| 12 | `pipeline_events (subsector_code, event_type, created_at)` | audit timeline |
| 13 | `pipeline_events USING gin (payload jsonb_path_ops)` | event payload search |
| 14 | `pipelines (subsector_code) WHERE status='active'` | partial — active-pipeline enumeration |
| 15 | `subsectors (sector, parent)` + GIN (economics) | registry/config lookups |
| 16 | `tenants (type, county_id)` + partial quadrant | county onboarding lists |

Integrity: every hot row FKs `subsector_code → subsectors.code` — a typo'd pipeline code
cannot enter the ledger. `(tenant_id, subsector_code)` UNIQUE on `pipelines` makes
"one activation per tenant per subsector" a database guarantee, not app discipline.

## 4. Sharding plan — honest, staged

**Key choice: `tenant_id` shards the transactional volume; `subsector_code` does NOT.**
The joiner, Mother-Pool, and trial balance aggregate ACROSS subsectors — sharding by
subsector would turn every one of those runs into a 152-way cross-shard fan-out. Sharding
by tenant (county/enterprise) keeps each tenant's orders/ledger/events co-located while the
governance tables stay on one primary as the cross-shard source of truth.

- **Level 0 — today (single primary):** all tables on Laravel Serverless Postgres; pgbouncer
  pooling absorbs connection load (~10k concurrent). Zero sharding complexity.
- **Level 1 — logical partitioning (already built):** monthly RANGE partitions on the 5 hot
  tables + DEFAULT safety nets; `PartitionManager::ensurePartitions()` pre-creates months
  ahead; `kicc:ensure-partitions --report` alerts when rows land in DEFAULT (missing month).
  Old months detach cheaply (`DETACH PARTITION`) for archival.
- **Level 2 — read replicas + read/write splitting:** Laravel's read/write connection arrays
  with `sticky` enabled (avoids read-your-writes anomalies after writes; see Laravel
  database docs read/write splitting). Reports, dashboards, dry-run distribution, and
  trial-balance scans go to replicas; writes and money-lifecycle transactions stay primary.
- **Level 3 — physical tenant shards (only on saturation):** `TenantConnectionResolver`
  routes tenant_id ranges → `pgsql_shard_a/b/...` via config('kicc-sharding.tenant_map').
  Migration path: (1) add shard connections, (2) migrate closed months per tenant
  (partitions make extraction = DETACH + attach on target), (3) flip the map, (4) keep
  Mother-Pool/joiner batches on the primary — they are the cross-shard reconciler.
- **Hot-partition handling:** pre-created future months; DEFAULT partition as tripwire;
  monitoring via `defaultPartitionLoad()`; if one tenant over-represents a month, split
  their history into a dedicated shard at Level 3 (their rows are cleanly range-isolatable
  via tenant_id within each monthly partition).

## 5. Scale triggers (when to move up a level)

| Signal | Metric | Action |
|---|---|---|
| Connection pressure | pgbouncer near pooling ceiling | verify pooling; raise app-side reuse; then Level 2 |
| Read saturation | replica-worthy read p95 > 500ms | Level 2 read replicas + sticky |
| Write saturation | primary write p95 > 200ms sustained / CPU > 70% | Level 3 tenant shards |
| Partition bloat | single month partition > ~2× others | check for tenant hot-spot; consider Level 3 for that tenant |
| DEFAULT partition rows > 0 | `kicc:ensure-partitions --report` | fix scheduler; move rows into correct month partition |

## 6. TiDB parity (your current production DB)

TiDB natively auto-shards into ~256MB regions across TiKV, so Level 3 is unnecessary there;
use the SAME logical design but translate: RANGE COLUMNS (created_at) monthly partitions
(TiDB supports Range/Range COLUMNS/List/List COLUMNS/Hash/Key; max 1024 partitions —
docs.pingcap.com/tidb/stable/partitioned-table). Differences to respect: INCLUDE indexes are
not supported (use plain composite (gl_account, created_at) — the covering optimisation is
approximated by TiDB's index+table locality); GIN/JSONB operators are MySQL JSON functions;
`gen_random_uuid()` → use UUID() or app-generated UUIDs. The Laravel migrations in this
module detect the driver and delegate: Postgres DDL as shipped, TiDB via the notes above.

## 7. Files in this module

- `sql/schema_postgres.sql` — full DDL (executed + verified against local PostgreSQL 16)
- `sql/index_plan.sql`, `sql/partitions.sql` — index + partition DDL
- `sql/seed_subsectors.sql` — 152-row registry seed generated from the kit's real config
- `database/migrations/2026_09_20_000{1,2,3}_*.php` — Laravel migration files (php -l clean)
- `app/Support/PartitionManager.php` + `app/Console/Commands/KiccEnsurePartitions.php`
- `app/Support/TenantConnectionResolver.php` + `config/kicc-sharding.php` (dormant Level 3)
