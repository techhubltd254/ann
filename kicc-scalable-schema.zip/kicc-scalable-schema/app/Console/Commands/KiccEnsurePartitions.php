<?php

namespace App\Console\Commands;

use App\Support\PartitionManager;
use Illuminate\Console\Command;

class KiccEnsurePartitions extends Command
{
    protected $signature = 'kicc:ensure-partitions {--months-ahead=2} {--report}';
    protected $description = 'Pre-create monthly partitions for hot tables (orders, ledger_*, pool_contributions, pipeline_events); --report shows DEFAULT-partition load';

    public function handle(): int
    {
        if ($this->option('report')) {
            foreach (PartitionManager::defaultPartitionLoad() as $table => $est) {
                $this->line(sprintf('%s_default: ~%d rows %s', $table, $est, $est > 0 ? '<-- ALERT: month partition missing' : '(ok)'));
            }
            return self::SUCCESS;
        }
        $created = PartitionManager::ensurePartitions((int) $this->option('months-ahead'));
        $this->info(count($created) ? 'created: ' . implode(', ', $created) : 'all partitions present');
        return self::SUCCESS;
    }
}
