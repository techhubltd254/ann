<?php

namespace App\Support;

/**
 * LEVEL-3 SHARD ROUTER (dormant until a single primary saturates — see
 * SCHEMA_SHARDING.md §4). Maps tenant_id -> a configured Laravel connection.
 * Until shard connections exist in config/database.php, everything routes to
 * the default 'pgsql' connection: zero behaviour change today.
 */
class TenantConnectionResolver
{
    /** @return string connection name for a tenant */
    public static function forTenant(int $tenantId): string
    {
        $map = config('kicc-sharding.tenant_map', []);   // ['1-200' => 'pgsql_shard_a', ...]
        foreach ($map as $range => $connection) {
            [$lo, $hi] = array_pad(explode('-', $range), 2, null);
            if ($tenantId >= (int) $lo && ($hi === null || $tenantId <= (int) $hi)) {
                return $connection;
            }
        }
        return config('kicc-sharding.default_connection', 'pgsql');
    }

    /** Mother-Pool / joiner reads ALWAYS go to the primary: cross-shard truth. */
    public static function forMotherPool(): string
    {
        return config('kicc-sharding.primary_connection', 'pgsql');
    }
}
