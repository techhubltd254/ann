<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/**
 * Pre-creates monthly RANGE partitions for the five hot tables.
 * Run on a schedule (e.g. daily): never let the DEFAULT partition take traffic.
 *
 *   php artisan kicc:ensure-partitions --months-ahead=2
 */
class PartitionManager
{
    public const HOT_TABLES = [
        'orders', 'ledger_transactions', 'ledger_entries', 'pool_contributions', 'pipeline_events',
    ];

    /** @return string[] names of partitions created */
    public static function ensurePartitions(int $monthsAhead = 2, ?string $from = null): array
    {
        $created = [];
        $first = new \DateTimeImmutable($from ?? now()->startOfMonth()->toDateTimeString());
        for ($i = -1; $i <= $monthsAhead; $i++) {          // keep last month too (late writes)
            $start = $first->modify("{$i} months");
            $end   = $start->modify('+1 month');
            $suffix = $start->format('Y_m');
            foreach (self::HOT_TABLES as $table) {
                $name = $table . '_' . $suffix;
                $exists = DB::selectOne('SELECT 1 FROM pg_class WHERE relname = ?', [$name]);
                if (!$exists) {
                    DB::statement(sprintf(
                        'CREATE TABLE IF NOT EXISTS %s PARTITION OF %s FOR VALUES FROM (%s) TO (%s)',
                        $name, $table,
                        DB::getPdo()->quote($start->format('Y-m-d 00:00:00')),
                        DB::getPdo()->quote($end->format('Y-m-d 00:00:00'))
                    ));
                    $created[] = $name;
                }
            }
        }
        return $created;
    }

    /** Alert condition: rows landing in the DEFAULT partition mean a missing month. */
    public static function defaultPartitionLoad(): array
    {
        $out = [];
        foreach (self::HOT_TABLES as $table) {
            $row = DB::selectOne(
                "SELECT coalesce(n_live_tup, 0) AS est
                 FROM pg_stat_all_tables WHERE relname = ?",
                [$table . '_default']
            );
            $out[$table] = (int) ($row->est ?? 0);
        }
        return $out;
    }

    /** Detach + archive a closed month (call from a monthly job). */
    public static function detachMonth(string $table, string $suffix): void
    {
        DB::statement(sprintf('ALTER TABLE %s DETACH PARTITION %s_%s', $table, $table, $suffix));
    }
}
