-- ============================================================================
-- INITIAL PARTITIONS: 3 months + DEFAULT safety net (per hot table).
-- PartitionManager::ensurePartitions() pre-creates future months on a schedule.
-- ============================================================================

DO $$
DECLARE
  t text;
  m text;
BEGIN
  FOR t IN SELECT unnest(ARRAY['orders','ledger_transactions','ledger_entries','pool_contributions','pipeline_events']) LOOP
    FOR m IN SELECT unnest(ARRAY['2026-09-01|2026-10-01|2026_09','2026-10-01|2026-11-01|2026_10','2026-11-01|2026-12-01|2026_11']) LOOP
      EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)',
        t || '_' || split_part(m, '|', 3), t, split_part(m, '|', 1), split_part(m, '|', 2));
    END LOOP;
    EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %I DEFAULT', t || '_default', t);
  END LOOP;
END $$;
