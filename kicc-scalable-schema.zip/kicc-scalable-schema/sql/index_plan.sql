
-- ============================================================================
-- INDEX PLAN — every index is justified by a named query pattern.
-- ============================================================================

-- Q1  Joiner per-pipeline monthly GMV rollup: SELECT subsector_code, SUM(gmv) FROM orders WHERE created_at >= x AND created_at < y GROUP BY 1
CREATE INDEX IF NOT EXISTS orders_pipeline_time_idx ON orders (subsector_code, created_at);
-- Q2  County attribution / county dashboards
CREATE INDEX IF NOT EXISTS orders_county_time_idx   ON orders (county_id, created_at);
-- Q3  Tenant account history
CREATE INDEX IF NOT EXISTS orders_tenant_time_idx   ON orders (tenant_id, created_at);
-- Q4  Pending-work queue (partial: tiny index, only open rows)
CREATE INDEX IF NOT EXISTS orders_pending_idx       ON orders (subsector_code, created_at) WHERE status = 'pending';
-- Q5  Ad-hoc subsector-specific attribute search without 152 schemas
CREATE INDEX IF NOT EXISTS orders_meta_gin          ON orders USING gin (meta jsonb_path_ops);

-- Q6  Ledger lifecycle lookups per pipeline
CREATE INDEX IF NOT EXISTS ltx_pipeline_time_idx    ON ledger_transactions (subsector_code, created_at);
-- Q7  Joiner batch reconciliation
CREATE INDEX IF NOT EXISTS ltx_batch_idx            ON ledger_transactions (uuid);
-- Q8  Trial balance scan reads only (gl_account, created_at, debit, credit) — covering, no heap visits
CREATE INDEX IF NOT EXISTS lentry_tb_covering_idx   ON ledger_entries (gl_account, created_at) INCLUDE (debit, credit);
-- Q9  Posting lookup / idempotency re-check
CREATE INDEX IF NOT EXISTS lentry_posting_key_idx   ON ledger_entries (posting_key);

-- Q10 Distribution computation per pool per pipeline
CREATE INDEX IF NOT EXISTS pool_pool_pipeline_idx   ON pool_contributions (mother_pool_id, subsector_code);
-- Q11 County equity reporting (equalisation earmark)
CREATE INDEX IF NOT EXISTS pool_county_time_idx     ON pool_contributions (county_id, created_at);

-- Q12 Per-pipeline audit timeline
CREATE INDEX IF NOT EXISTS pevent_pipeline_type_idx ON pipeline_events (subsector_code, event_type, created_at);
-- Q13 Event payload search
CREATE INDEX IF NOT EXISTS pevent_payload_gin       ON pipeline_events USING gin (payload jsonb_path_ops);

-- Q14 Active-pipeline enumeration for joiner dry-run (partial)
CREATE INDEX IF NOT EXISTS pipelines_active_idx     ON pipelines (subsector_code) WHERE status = 'active';
-- Q15 Config-style registry lookups
CREATE INDEX IF NOT EXISTS subsectors_sector_idx    ON subsectors (sector, parent);
CREATE INDEX IF NOT EXISTS subsectors_econ_gin      ON subsectors USING gin (economics jsonb_path_ops);
-- Q16 County onboarding lists
CREATE INDEX IF NOT EXISTS tenants_type_county_idx  ON tenants (type, county_id);
CREATE INDEX IF NOT EXISTS tenants_quadrant_active_idx ON tenants (quadrant) WHERE status = 'active';
