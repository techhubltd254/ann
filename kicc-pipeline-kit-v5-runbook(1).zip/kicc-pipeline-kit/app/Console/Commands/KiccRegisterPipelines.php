<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class KiccRegisterPipelines extends Command
{
    protected $signature = 'kicc:register-pipelines';
    protected $description = 'Register/sync every pipeline from config/kicc-pipelines.php into pipeline_registrations';

    public function handle(): int
    {
        $count = 0;
        foreach (config('kicc-pipelines') as $p) {
            DB::table('pipeline_registrations')->updateOrInsert(
                ['pipeline_code' => $p['code']],
                [
                    'phase' => $p['phase'],
                    'status' => $p['status'] === 'built' ? 'active' : 'registered',
                    'economics' => json_encode(['take_rate' => $p['take_rate']]),
                    'regulators' => json_encode($p['regulators']),
                    'kill_criteria' => json_encode(['max_dispute_rate_pct' => 3, 'min_fill_rate_pct' => 70]),
                    'updated_at' => now(), 'created_at' => now(),
                ]
            );
            $count++;
        }
        $this->info("Registered/updated {$count} pipelines.");
        return self::SUCCESS;
    }
}
