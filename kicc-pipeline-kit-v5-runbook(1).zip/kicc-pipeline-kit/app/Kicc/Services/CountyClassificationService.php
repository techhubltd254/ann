<?php

namespace App\Kicc\Services;

use Illuminate\Support\Facades\DB;

/**
 * RPS (Revenue Potential Score) and FNS (Foundational/Strategic Need Score)
 * → quadrant: engine | growth | priority | anchor.
 * Weights come from config/kicc-county-classification.php.
 */
class CountyClassificationService
{
    public function classify(int $countyId, array $indicators): array
    {
        $w = config('kicc-county-classification.weights');
        $rps = 0.0;
        foreach ($w['rps'] as $key => $weight) {
            $rps += ($indicators[$key] ?? 0) * $weight;
        }
        $fns = 0.0;
        foreach ($w['fns'] as $key => $weight) {
            $fns += ($indicators[$key] ?? 0) * $weight;
        }
        $quadrant = $this->quadrant($rps, $fns);
        DB::table('county_classifications')->updateOrInsert(
            ['county_id' => $countyId],
            ['rps_score' => round($rps, 2), 'fns_score' => round($fns, 2), 'quadrant' => $quadrant,
             'effective_from' => now()->toDateString(), 'updated_at' => now(), 'created_at' => now()]
        );
        return ['rps' => round($rps, 2), 'fns' => round($fns, 2), 'quadrant' => $quadrant];
    }

    public function quadrant(float $rps, float $fns): string
    {
        $t = config('kicc-county-classification.thresholds');
        if ($rps >= $t['rps_high']) return $fns >= $t['fns_high'] ? 'engine' : 'growth';
        return $fns >= $t['fns_high'] ? 'priority' : 'anchor';
    }

    /** Which pipeline codes may be activated for a quadrant (activation tiers). */
    public function activationTierFor(string $quadrant): array
    {
        return config('kicc-county-classification.activation_tiers.' . $quadrant, []);
    }
}
