<?php

/*
|--------------------------------------------------------------------------
| CORE: General Ledger (double-entry), escrow lifecycle, Mother-Pool, quality metrics, county classification (RPS/FNS), pipeline registry
|--------------------------------------------------------------------------
| Generated for the KICC Pipeline Kit. Every table is guarded with
| Schema::hasTable() so this migration is IDEMPOTENT and non-destructive:
| existing tables (including anything already live in TiDB) are never touched.
*/

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Double-entry chart of accounts
        if (!Schema::hasTable('gl_accounts')) {
            Schema::create('gl_accounts', function (Blueprint $table) {
                $table->id();
            $table->string('code')->unique();
            $table->string('name');
            $table->string('type')->default('asset');
            $table->string('currency')->default('KES');
            $table->unsignedBigInteger('parent_id')->index()->nullable();
            $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        // Journal header
        if (!Schema::hasTable('gl_journal_entries')) {
            Schema::create('gl_journal_entries', function (Blueprint $table) {
                $table->id();
            $table->string('entry_no')->unique();
            $table->string('reference_type')->nullable();
            $table->unsignedBigInteger('reference_id')->index()->nullable();
            $table->string('description')->nullable();
            $table->dateTime('posted_at')->nullable();
            $table->unsignedBigInteger('reversal_of')->nullable();
                $table->timestamps();
            });
        }

        // Journal lines — debits must equal credits per entry
        if (!Schema::hasTable('gl_journal_lines')) {
            Schema::create('gl_journal_lines', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('journal_entry_id')->index();
            $table->unsignedBigInteger('gl_account_id')->index();
            $table->decimal('debit', 18, 2)->default(0);
            $table->decimal('credit', 18, 2)->default(0);
            $table->string('memo')->nullable();
                $table->timestamps();
            });
        }

        // Money lifecycle: hold → capture → split → release/refund
        if (!Schema::hasTable('ledger_transactions')) {
            Schema::create('ledger_transactions', function (Blueprint $table) {
                $table->id();
            $table->string('uuid')->unique();
            $table->string('pipeline_code')->index();
            $table->unsignedBigInteger('sector_id')->index()->nullable();
            $table->unsignedBigInteger('user_id')->index()->nullable();
            $table->string('type')->default('hold');
            $table->decimal('amount', 18, 2);
            $table->string('currency')->default('KES');
            $table->string('status')->default('pending');
            $table->string('reference_type')->nullable();
            $table->unsignedBigInteger('reference_id')->index()->nullable();
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->json('meta')->nullable();
            $table->string('status')->default('pending');
                $table->timestamps();
            });
        }

        // Escrow hold records
        if (!Schema::hasTable('ledger_holds')) {
            Schema::create('ledger_holds', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('ledger_transaction_id')->index();
            $table->decimal('amount', 18, 2);
            $table->dateTime('held_at')->nullable();
            $table->dateTime('expires_at')->nullable();
            $table->dateTime('released_at')->nullable();
                $table->timestamps();
            });
        }

        // Vendor payout waterfall
        if (!Schema::hasTable('ledger_splits')) {
            Schema::create('ledger_splits', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('ledger_transaction_id')->index();
            $table->string('payee_type');
            $table->unsignedBigInteger('payee_id')->index();
            $table->string('split_code');
            $table->decimal('amount', 18, 2);
            $table->string('status')->default('pending');
            $table->dateTime('paid_at')->nullable();
            $table->json('meta')->nullable();
                $table->timestamps();
            });
        }

        // Mother-Pool header per period
        if (!Schema::hasTable('mother_pools')) {
            Schema::create('mother_pools', function (Blueprint $table) {
                $table->id();
            $table->string('name');
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->unsignedBigInteger('sector_id')->index()->nullable();
            $table->date('period_start');
            $table->date('period_end');
            $table->decimal('total_collected', 18, 2)->default(0);
            $table->decimal('holdback_amount', 18, 2)->default(0);
            $table->decimal('equalisation_amount', 18, 2)->default(0);
            $table->string('distribution_status')->default('open');
            $table->dateTime('distributed_at')->nullable();
                $table->timestamps();
            });
        }

        // Per-pipeline contribution into the pool
        if (!Schema::hasTable('pool_contributions')) {
            Schema::create('pool_contributions', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('mother_pool_id')->index();
            $table->string('pipeline_code')->index();
            $table->unsignedBigInteger('sector_id')->index()->nullable();
            $table->decimal('gmv', 18, 2)->default(0);
            $table->decimal('fee_charged', 18, 2)->default(0);
            $table->decimal('vendor_payout', 18, 2)->default(0);
            $table->decimal('kicc_net', 18, 2)->default(0);
            $table->decimal('holdback', 18, 2)->default(0);
            $table->decimal('equalisation', 18, 2)->default(0);
            $table->decimal('quality_multiplier', 5, 2)->default(1);
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->json('meta')->nullable();
            $table->string('status')->default('pending');
                $table->timestamps();
            });
        }

        // Computed distribution outcomes
        if (!Schema::hasTable('pool_distributions')) {
            Schema::create('pool_distributions', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('mother_pool_id')->index();
            $table->string('beneficiary_type');
            $table->unsignedBigInteger('beneficiary_id')->index();
            $table->decimal('amount', 18, 2);
            $table->string('basis')->default('contribution_x_quality');
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->json('meta')->nullable();
            $table->string('status')->default('pending');
                $table->timestamps();
            });
        }

        // Quality score inputs → multiplier
        if (!Schema::hasTable('quality_metrics')) {
            Schema::create('quality_metrics', function (Blueprint $table) {
                $table->id();
            $table->string('pipeline_code')->index();
            $table->string('period');
            $table->decimal('fill_rate', 5, 2)->default(100);
            $table->decimal('dispute_rate', 5, 2)->default(0);
            $table->decimal('data_completeness', 5, 2)->default(100);
            $table->decimal('delivery_reliability', 5, 2)->default(100);
            $table->decimal('multiplier', 5, 2)->default(1);
                $table->timestamps();
            });
        }

        // RPS/FNS → quadrant: engine / growth / priority / anchor
        if (!Schema::hasTable('county_classifications')) {
            Schema::create('county_classifications', function (Blueprint $table) {
                $table->id();
            $table->unsignedBigInteger('county_id')->unique();
            $table->decimal('rps_score', 6, 2)->default(0);
            $table->decimal('fns_score', 6, 2)->default(0);
            $table->string('quadrant')->default('growth');
            $table->text('notes')->nullable();
            $table->date('effective_from')->nullable();
                $table->timestamps();
            });
        }

        // Registry of all pipelines with economics + kill criteria
        if (!Schema::hasTable('pipeline_registrations')) {
            Schema::create('pipeline_registrations', function (Blueprint $table) {
                $table->id();
            $table->string('pipeline_code')->unique();
            $table->unsignedBigInteger('sector_id')->index()->nullable();
            $table->string('phase')->default(1);
            $table->string('status')->default('registered');
            $table->json('economics')->nullable();
            $table->json('kill_criteria')->nullable();
            $table->json('regulators')->nullable();
            $table->dateTime('activated_at')->nullable();
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->json('meta')->nullable();
            $table->string('status')->default('pending');
                $table->timestamps();
            });
        }

        // Audit trail for every pipeline action
        if (!Schema::hasTable('pipeline_events')) {
            Schema::create('pipeline_events', function (Blueprint $table) {
                $table->id();
            $table->string('pipeline_code')->index();
            $table->string('event_type')->index();
            $table->json('payload')->nullable();
            $table->unsignedBigInteger('county_id')->index()->nullable();
            $table->json('meta')->nullable();
            $table->string('status')->default('pending');
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('gl_accounts');
        Schema::dropIfExists('gl_journal_entries');
        Schema::dropIfExists('gl_journal_lines');
        Schema::dropIfExists('ledger_transactions');
        Schema::dropIfExists('ledger_holds');
        Schema::dropIfExists('ledger_splits');
        Schema::dropIfExists('mother_pools');
        Schema::dropIfExists('pool_contributions');
        Schema::dropIfExists('pool_distributions');
        Schema::dropIfExists('quality_metrics');
        Schema::dropIfExists('county_classifications');
        Schema::dropIfExists('pipeline_registrations');
        Schema::dropIfExists('pipeline_events');
    }
};
