# KICC Pipeline Kit — Integration Guide

Generated 2026-09-17. This kit completes the `ann` (KICC Laravel 13 / TiDB) platform with
**all 49 documented pipelines**, the **General Ledger**, and the **Mother-Pool** engine —
the two missing engines every revenue line depends on.

## ⚠️ SECURITY FIRST
The TiDB credentials pasted in chat are now **exposed — rotate them immediately**
in the TiDB Cloud console. This kit contains **no credentials**; it reads config from
`.env` only. See `.env.example.additions`.

## What's inside

```
kicc-pipeline-kit/
├── database/migrations/            11 idempotent migrations (~100 tables)
├── app/Kicc/
│   ├── Contracts/PipelineContract.php
│   ├── Pipelines/AbstractPipeline.php   + 49 concrete pipeline classes
│   ├── Services/LedgerService.php       double-entry + hold/capture/split/release/refund
│   ├── Services/MotherPoolService.php   contribution × quality distribution
│   ├── Services/QualityScoreService.php multiplier clipped to [0.8, 1.2]
│   ├── Services/CountyClassificationService.php  RPS/FNS → quadrant
│   └── Support/Economics.php            holdback 10% + equalisation 0.5% math
├── app/Console/Commands/           kicc:register-pipelines, kicc:dry-run-distribution
├── config/kicc-pipelines.php       registry of all 49 pipelines
├── config/kicc-county-classification.php    RPS/FNS weights + activation tiers
└── .env.example.additions
```

## Migration order (copy files, then `php artisan migrate`)

1. `2026_09_17_000001_restore_dropped_tables_safely.php` — restores the tables dropped in the
   2026-09-13 TiDB incident (product_questions, wishlists, rfqs + children). **Every create is
   guarded with `Schema::hasTable` — it will never drop or overwrite your live tables.** If your
   live versions of these tables have different columns, keep the guard: it skips them harmlessly.
2. `..._000002_create_core_ledger_and_mother_pool.php` — GL, escrow lifecycle, Mother-Pool,
   quality metrics, county classification, pipeline registry.
3. `..._000003` … `..._000011` — the nine sector clusters:

| `database/migrations/2026_09_17_000003_create_trade_commerce_pipelines.php` | 10 tables | logistics_shipments, logistics_carrier_quotes, groupbuy_campaigns, groupbuy_orders, county_wholesale_listings, market_day_sales, franchise_listings, franchise_matches, sme_business_listings, sme_acquisition_deals |
| `database/migrations/2026_09_17_000004_create_agriculture_pipelines.php` | 12 tables | agri_lots, agri_lot_transactions, coop_pooling_batches, coop_lot_consignments, livestock_listings, livestock_sales, fisheries_catches, fisheries_sales, hort_export_permits, hort_compliance_documents, input_financing_advances, input_financing_repayments |
| `database/migrations/2026_09_17_000005_create_tourism_pipelines.php` | 11 tables | experience_bookings, experience_availability, trip_itineraries, trip_itinerary_items, tour_packages, tour_package_bookings, homestay_listings, homestay_bookings, venue_listings, venue_bookings, booth_inventory |
| `database/migrations/2026_09_17_000006_create_investment_industry_pipelines.php` | 10 tables | sez_investor_leads, sez_deals, sez_workforce_requests, sez_placements, real_estate_listings, real_estate_deals, diaspora_investment_projects, diaspora_investments, mining_listings, mining_deals |
| `database/migrations/2026_09_17_000007_create_financing_risk_pipelines.php` | 10 tables | financing_facilities, financing_disbursements, invoice_financing_requests, invoice_financing_deals, input_advance_requests, input_advance_deals, embedded_insurance_policies, kyb_checks, escrow_float_accounts, escrow_float_yields |
| `database/migrations/2026_09_17_000008_create_government_pipelines.php` | 10 tables | county_revenue_heads, county_revenue_collections, county_procurement_pos, county_procurement_escrows, national_procurement_tenders, national_procurement_escrows, egov_service_catalog, egov_transactions, data_products, data_product_subscriptions |
| `database/migrations/2026_09_17_000009_create_health_education_pipelines.php` | 14 tables | health_supply_catalog, health_supply_orders, health_facility_subscriptions, telehealth_sessions, skills_job_vacancies, skills_placements, labour_migration_applications, labour_migration_verifications, edu_institution_fees, edu_fee_transactions, attachment_opportunities, attachment_placements, tvet_equipment_listings, tvet_equipment_orders |
| `database/migrations/2026_09_17_000010_create_energy_mobility_pipelines.php` | 13 tables | energy_products, energy_payg_contracts, carbon_projects, carbon_credit_trades, water_capex_projects, water_project_deals, waste_listings, waste_transactions, sacco_vehicles, sacco_daily_collections, freight_loads, freight_bids, fleet_fuel_orders |
| `database/migrations/2026_09_17_000011_create_creative_identity_pipelines.php` | 6 tables | stream_sessions, stream_passes, stream_tips, sports_talent_profiles, sports_deals, kyb_verification_requests |

## Every pipeline: code → sector → file → tables

| Code | Sector | Pipeline | Phase | Status | Module file | Tables created |
|---|---|---|---|---|---|---|
| `A1` | trade | Domestic Marketplace (ALREADY BUILT in ann — this kit wires it into the ledger) | 1 | built | app/Kicc/Pipelines/A1Pipeline.php | products, orders |
| `A2` | trade | Cross-Border Logistics | 1 | absent | app/Kicc/Pipelines/A2Pipeline.php | logistics_shipments, logistics_carrier_quotes |
| `A3` | trade | Construction Materials Group-Buy | 1 | absent | app/Kicc/Pipelines/A3Pipeline.php | groupbuy_campaigns, groupbuy_orders |
| `A4` | trade | County Wholesale & Market-Day Trade | 1 | absent | app/Kicc/Pipelines/A4Pipeline.php | county_wholesale_listings, market_day_sales |
| `A5` | trade | Franchise & Dealership Matchmaking | 1 | absent | app/Kicc/Pipelines/A5Pipeline.php | franchise_listings, franchise_matches |
| `A6` | trade | SME Acquisition / Business-for-Sale | 3 | absent | app/Kicc/Pipelines/A6Pipeline.php | sme_business_listings, sme_acquisition_deals |
| `B1` | agriculture | Agriculture Lots (grading / split payout) | 1 | absent | app/Kicc/Pipelines/B1Pipeline.php | agri_lots, agri_lot_transactions |
| `B2` | agriculture | Cooperative Rail | 1 | absent | app/Kicc/Pipelines/B2Pipeline.php | coop_pooling_batches, coop_lot_consignments |
| `B3` | agriculture | Livestock & Leather | 1 | absent | app/Kicc/Pipelines/B3Pipeline.php | livestock_listings, livestock_sales |
| `B4` | agriculture | Fisheries & Blue Economy | 1 | absent | app/Kicc/Pipelines/B4Pipeline.php | fisheries_catches, fisheries_sales |
| `B5` | agriculture | Horticulture Export Compliance Desk | 2 | absent | app/Kicc/Pipelines/B5Pipeline.php | hort_export_permits, hort_compliance_documents |
| `B6` | agriculture | Agri-Input Financing Feeder | 3 | licence_gated | app/Kicc/Pipelines/B6Pipeline.php | input_financing_advances, input_financing_repayments |
| `C1` | tourism | Tourism & Experiences | 1 | partial | app/Kicc/Pipelines/C1Pipeline.php | experience_bookings, experience_availability |
| `C2` | tourism | Itinerary / Trip Planning | 1 | partial | app/Kicc/Pipelines/C2Pipeline.php | trip_itineraries, trip_itinerary_items |
| `C3` | tourism | Bundled Tourism (Merchant of Record) | 2 | absent | app/Kicc/Pipelines/C3Pipeline.php | tour_packages, tour_package_bookings |
| `C4` | tourism | County Homestay & Community Tourism | 1 | absent | app/Kicc/Pipelines/C4Pipeline.php | homestay_listings, homestay_bookings |
| `C5` | tourism | MICE / Venue & Booths | 1 | partial | app/Kicc/Pipelines/C5Pipeline.php | venue_listings, venue_bookings, booth_inventory |
| `D1` | investment | Industrial / SEZ Facilitation | 2 | absent | app/Kicc/Pipelines/D1Pipeline.php | sez_investor_leads, sez_deals |
| `D2` | investment | SEZ Workforce Matching | 2 | absent | app/Kicc/Pipelines/D2Pipeline.php | sez_workforce_requests, sez_placements |
| `D3` | investment | Real Estate (title-verified) | 2 | blocked | app/Kicc/Pipelines/D3Pipeline.php | real_estate_listings, real_estate_deals |
| `D4` | investment | Diaspora Investment Corridor | 2 | absent | app/Kicc/Pipelines/D4Pipeline.php | diaspora_investment_projects, diaspora_investments |
| `D5` | investment | Mining Value-Chain Services | 2 | absent | app/Kicc/Pipelines/D5Pipeline.php | mining_listings, mining_deals |
| `F1` | financing | Financing & Treasury | 3 | licence_gated | app/Kicc/Pipelines/F1Pipeline.php | financing_facilities, financing_disbursements |
| `F2` | financing | Supplier / Invoice Financing | 3 | licence_gated | app/Kicc/Pipelines/F2Pipeline.php | invoice_financing_requests, invoice_financing_deals |
| `F3` | financing | Input Financing | 3 | licence_gated | app/Kicc/Pipelines/F3Pipeline.php | input_advance_requests, input_advance_deals |
| `F4` | financing | Embedded Insurance + KYB-as-a-Service | 2 | absent | app/Kicc/Pipelines/F4Pipeline.php | embedded_insurance_policies, kyb_checks |
| `F5` | financing | Escrow Float / Treasury Yield | 3 | licence_gated | app/Kicc/Pipelines/F5Pipeline.php | escrow_float_accounts, escrow_float_yields |
| `G1` | government | County Own-Source Revenue Rail | 1 | absent | app/Kicc/Pipelines/G1Pipeline.php | county_revenue_heads, county_revenue_collections |
| `G2` | government | County Procurement Rail | 3 | licence_gated | app/Kicc/Pipelines/G2Pipeline.php | county_procurement_pos, county_procurement_escrows |
| `H1` | government | National Procurement (IFMIS-aligned) | 3 | licence_gated | app/Kicc/Pipelines/H1Pipeline.php | national_procurement_tenders, national_procurement_escrows |
| `G3` | government | e-Government Services Facilitation | 2 | absent | app/Kicc/Pipelines/G3Pipeline.php | egov_service_catalog, egov_transactions |
| `G4` | government | Market Intelligence / Data Products | 1 | absent | app/Kicc/Pipelines/G4Pipeline.php | data_products, data_product_subscriptions |
| `K1` | health | Health Facility Supply Marketplace | 2 | absent | app/Kicc/Pipelines/K1Pipeline.php | health_supply_catalog, health_supply_orders |
| `K2` | health | Clinic/Hospital Back-office SaaS | 2 | absent | app/Kicc/Pipelines/K2Pipeline.php | health_facility_subscriptions |
| `K3` | health | Telehealth / Health-Data layer | 2 | blocked | app/Kicc/Pipelines/K3Pipeline.php | telehealth_sessions |
| `L1` | education | Skills-to-Jobs (TVET) | 1 | absent | app/Kicc/Pipelines/L1Pipeline.php | skills_job_vacancies, skills_placements |
| `L2` | education | Labour Migration Desk | 2 | absent | app/Kicc/Pipelines/L2Pipeline.php | labour_migration_applications, labour_migration_verifications |
| `L3` | education | Edu Commerce & Fee Rails | 1 | absent | app/Kicc/Pipelines/L3Pipeline.php | edu_institution_fees, edu_fee_transactions |
| `L4` | education | University/Industry Attachment & IP Exchange | 1 | absent | app/Kicc/Pipelines/L4Pipeline.php | attachment_opportunities, attachment_placements |
| `L5` | education | TVET Equipment & Consumables Trade | 1 | absent | app/Kicc/Pipelines/L5Pipeline.php | tvet_equipment_listings, tvet_equipment_orders |
| `M1` | energy | Clean-Energy Commerce + PAYG escrow | 2 | absent | app/Kicc/Pipelines/M1Pipeline.php | energy_products, energy_payg_contracts |
| `M2` | energy | Carbon & Climate Assets | 2 | absent | app/Kicc/Pipelines/M2Pipeline.php | carbon_projects, carbon_credit_trades |
| `M3` | energy | Water Infrastructure Matchmaking | 2 | absent | app/Kicc/Pipelines/M3Pipeline.php | water_capex_projects, water_project_deals |
| `M4` | energy | Waste / Recycling Exchange | 1 | absent | app/Kicc/Pipelines/M4Pipeline.php | waste_listings, waste_transactions |
| `N1` | mobility | PSV / Matatu SACCO Operations | 2 | absent | app/Kicc/Pipelines/N1Pipeline.php | sacco_vehicles, sacco_daily_collections |
| `N2` | mobility | Freight & Loads Marketplace | 1 | absent | app/Kicc/Pipelines/N2Pipeline.php | freight_loads, freight_bids |
| `N3` | mobility | Fuel & Fleet Inputs | 2 | absent | app/Kicc/Pipelines/N3Pipeline.php | fleet_fuel_orders |
| `O1` | creative | Creative & Livestream Economy | 1 | partial | app/Kicc/Pipelines/O1Pipeline.php | stream_sessions, stream_passes, stream_tips |
| `O2` | creative | Sports Talent & Events | 3 | absent | app/Kicc/Pipelines/O2Pipeline.php | sports_talent_profiles, sports_deals |
| `P1` | identity | KYB-as-a-Service | 1 | absent | app/Kicc/Pipelines/P1Pipeline.php | kyb_verification_requests |

Phase key: **1** = no external blocker · **2** = needs volume/partners · **3** = licence-gated (CBK/IFMIS/IRA).
Status: `built` = already in `ann` (wire it up) · `partial` = module exists, money flow missing ·
`absent` = new here · `blocked`/`licence_gated` = regulator-gated — **preFlight() returns the blockers and the pipeline refuses to earn until cleared.**

## Integration steps (in order)

1. **Copy the tree** into your Laravel app root (paths already mirror a standard Laravel 13 app).
2. `php artisan migrate` — all migrations are idempotent; safe on the live TiDB.
3. `php artisan kicc:register-pipelines` — fills `pipeline_registrations` from the config registry.
4. Wire money flows:
   ```php
   use App\Kicc\Services\LedgerService;
   use App\Kicc\Services\MotherPoolService;

   $ledger = app(LedgerService::class);
   $txId   = $ledger->hold('C3', 480000.00, 'tour_package_booking', $booking->id, $countyId, $userId);
   // ... travel completed:
   $ledger->capture($txId);
   $ledger->split($txId, [
       ['payee_type' => 'hotel', 'payee_id' => $hotelId, 'split_code' => 'hotels', 'amount' => 260000],
       ['payee_type' => 'park',  'payee_id' => $kwsId,   'split_code' => 'attractions', 'amount' => 80000],
   ]);
   app(MotherPoolService::class)->recordContribution($poolId, 'C3', 480000, 96000, $countyId, $sectorId);
   ```
5. Monthly: `php artisan kicc:dry-run-distribution` → review → rerun with `--commit`.
6. County rollout: fill indicators in `county_classifications` via `CountyClassificationService::classify()`,
   then activate pipeline tiers per quadrant (config `activation_tiers`).

## Design rules baked in

- **Idempotent migrations** — `hasTable` guards everywhere; safe against the TiDB incident repeating.
- **No foreign-key constraints** — TiDB-safe; integrity enforced in `LedgerService` transactions.
- **Kill criteria on every pipeline** — max dispute 3%, min fill 70%, 2 consecutive months.
- **Dry-run governance** — the multiplier is disabled until you consciously `--commit`.
- **preFlight() blockers** — licence-gated pipelines physically refuse to earn until cleared.


---

# Mother-Pipeline Joiner Engine

Orchestrates and reconciles **all 152 subsector pipelines** into unified General Ledger
postings and Mother-Pool contributions — one deterministic batch per run.

## Files

| File | Role |
|---|---|
| `app/Kicc/Joiner/MotherPipelineJoiner.php` | Pure core: deterministic registry ordering, unified plan builder, reconciler, canonical idempotency hash (no framework deps) |
| `app/Kicc/Services/JoinerService.php` | Execution: persists runs/postings/reconciliations, posts unified journals **through** `LedgerService` (balanced-or-throw), records contributions **through** `MotherPoolService` |
| `database/migrations/2026_09_17_000013_create_joiner_tables.php` | `joiner_runs` (batch_id UNIQUE), `joiner_postings` (posting_key UNIQUE = DB-level duplicate guard), `joiner_reconciliations` |
| `app/Console/Commands/KiccJoinerRun.php` | `kicc:joiner:run` — dry-run / commit / per-sector / rate-mode |
| `app/Console/Commands/KiccSelftestJoiner.php` | `kicc:selftest-joiner` — full DB E2E with `--cleanup` |
| `tests/selftest_joiner_core.php` | Framework-free E2E over every discovered subsector (sandbox/CI) |

## Semantics

- **Deterministic order:** sector → parent → code; identical inputs always produce an identical plan and the same `batch_id` (`JPB-YYYYMMDD-<sha1[0..12]>`).
- **Unified postings:** per active pipeline, a balanced pair — `escrow_clearing` Dr gmv / `merchant_payable` Cr gmv, then `merchant_payable` Dr fee / `fees_income` Cr fee.
- **Mother-Pool:** every active pipeline contributes `gmv`, `fee`, `holdback` (10%), `equalisation` (0.5%), `kicc_net`, `vendor_payout` via `MotherPoolService::recordContribution()`.
- **Locked pipelines:** all CBK/IFMIS/blocked subsectors (`B6.*`, `D3.*`, `F1.*`–`F5.*` locked ones, `G2.*`, `H1.*`, `K3.*`) are reported in the plan but produce **zero postings** until their regulator gate clears.
- **Reconciliation:** per-pipeline debits==credits, whole-plan per-account trial balance, fee-split and gmv-split identities, totals tie-out — any failure surfaces in the variance report (and `reconcile()` returns `balanced=false`).
- **Idempotency:** same inputs → same `batch_id` and `posting_key`s; a repeated committed run is `already_posted` (no-op), enforced in code AND by the UNIQUE `posting_key` index.

## Usage

```bash
php artisan migrate                                  # 000013 creates the joiner tables
php tests/selftest_joiner_core.php                   # pure E2E (no DB): exit 0 required
php artisan kicc:joiner:run                          # dry-run plan over all subsectors
php artisan kicc:joiner:run --sector=tourism         # one sector
php artisan kicc:joiner:run --rate=optimistic        # upper take-rate bounds
php artisan kicc:joiner:run --commit --pool=1        # post to GL + record pool contributions
php artisan kicc:selftest-joiner --cleanup           # DB E2E on deploy, then clean up
```

The `--gmv` value (default 100000) is a **planning-scenario input**, not a forecast: it sizes the
plan so every pipeline's wiring, take rates, and pool math can be validated before real traffic.
