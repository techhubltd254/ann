<?php

namespace App\Console\Commands;

use App\Kicc\Services\MotherPoolService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class KiccDryRunDistribution extends Command
{
    protected $signature = 'kicc:dry-run-distribution {--pool=} {--commit : Actually settle (default is dry-run preview)}';
    protected $description = 'Preview or settle Mother-Pool distribution (dry-run forces quality multiplier to 1.0; settlement is idempotent)';

    public function handle(MotherPoolService $pools): int
    {
        $query = DB::table('mother_pools');
        if (!$this->option('commit')) $query->where('distribution_status', '!=', 'settled');
        if ($this->option('pool')) $query->where('id', (int) $this->option('pool'));

        foreach ($query->get() as $pool) {
            $res = $pools->settlePool($pool->id, !$this->option('commit'));
            $this->info("Pool #{$pool->id} ({$pool->name}) — status: {$res['status']}");
            foreach (($res['plan']['rows'] ?? []) as $r) {
                $this->line(sprintf('  %s | county %s | share %.2f%% | KES %s',
                    $r['pipeline_code'], $r['county_id'] ?? '-', $r['share_pct'] ?? 0, number_format($r['amount'] ?? 0, 2)));
            }
            if (($res['status'] ?? '') === 'settled') {
                $this->warn('  → SETTLED (idempotent, exact cents). total=' . number_format($res['total_distributed'], 2));
            }
            if (($res['status'] ?? '') === 'already_settled') {
                $this->line('  → already settled (' . $res['distributions'] . ' rows) — no action taken.');
            }
        }
        return self::SUCCESS;
    }
}
