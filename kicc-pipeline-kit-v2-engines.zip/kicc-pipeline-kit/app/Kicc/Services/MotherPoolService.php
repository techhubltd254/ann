<?php

namespace App\Kicc\Services;

use App\Kicc\Support\Economics;
use App\Kicc\Support\RemainderAllocator;
use Illuminate\Support\Facades\DB;

/**
 * Mother-Pool engine: collects every pipeline contribution and distributes
 * by contribution × quality, with 10% holdback + 0.5% equalisation earmark.
 *
 * Settlement guarantees:
 *  - idempotent: settling a settled pool is a no-op (returns already_settled)
 *  - exact cents: RemainderAllocator makes rows sum EXACTLY to total_collected
 *  - dry-run governance: multiplier forced to 1.0 unless explicitly committed
 */
class MotherPoolService
{
    public function __construct(private LedgerService $ledger) {}

    public function openPool(string $name, string $periodStart, string $periodEnd, ?int $countyId = null, ?int $sectorId = null): int
    {
        return DB::table('mother_pools')->insertGetId([
            'name' => $name, 'county_id' => $countyId, 'sector_id' => $sectorId,
            'period_start' => $periodStart, 'period_end' => $periodEnd,
            'distribution_status' => 'open',
            'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    public function recordContribution(int $poolId, string $pipelineCode, float $gmv, float $fee, ?int $countyId = null, ?int $sectorId = null, ?string $period = null): int
    {
        $multiplier = app(QualityScoreService::class)->multiplierFor($pipelineCode, $countyId, $period ?? now()->format('Y-m'));
        $data = Economics::contribution($poolId, $pipelineCode, $gmv, $fee, $countyId, $sectorId, $multiplier);
        $id = DB::table('pool_contributions')->insertGetId($data + ['status' => 'recorded', 'created_at' => now(), 'updated_at' => now()]);
        DB::table('mother_pools')->where('id', $poolId)->increment('total_collected', $data['kicc_net']);
        DB::table('mother_pools')->where('id', $poolId)->increment('holdback_amount', $data['holdback']);
        DB::table('mother_pools')->where('id', $poolId)->increment('equalisation_amount', $data['equalisation']);
        return $id;
    }

    /**
     * Compute distribution for a pool. In dry-run mode the quality
     * multiplier is FORCED to 1.0 (per the strategy doc's governance rule).
     */
    public function computeDistribution(int $poolId, bool $dryRun = true): array
    {
        $contribs = DB::table('pool_contributions')->where('mother_pool_id', $poolId)->get();
        $rows = [];
        foreach ($contribs as $c) {
            $m = $dryRun ? 1.0 : (float) $c->quality_multiplier;
            $rows[] = [
                'county_id' => $c->county_id, 'pipeline_code' => $c->pipeline_code,
                'basis_amount' => round($c->kicc_net * $m, 2),
            ];
        }
        $total = array_sum(array_column($rows, 'basis_amount'));
        if ($total <= 0) return ['rows' => [], 'total' => 0.0];
        foreach ($rows as &$r) {
            $r['share_pct'] = round($r['basis_amount'] / $total * 100, 4);
            $r['amount'] = round($r['basis_amount'] / $total * (float) DB::table('mother_pools')->where('id', $poolId)->value('total_collected'), 2);
        }
        return ['rows' => $rows, 'total' => $total, 'dry_run' => $dryRun];
    }

    /**
     * THE settlement entrypoint.
     *  $dryRun=true  → preview only (multiplier disabled), pool untouched
     *  $dryRun=false → idempotent exact-cent settlement; second call no-ops
     */
    public function settlePool(int $poolId, bool $dryRun = true): array
    {
        $pool = DB::table('mother_pools')->where('id', $poolId)->first();
        abort_if(!$pool, 404, 'Mother pool not found');

        if ($pool->distribution_status === 'settled') {
            return [
                'status' => 'already_settled',
                'pool_id' => $poolId,
                'distributions' => DB::table('pool_distributions')->where('mother_pool_id', $poolId)->count(),
            ];
        }

        $plan = $this->computeDistribution($poolId, $dryRun);
        if (empty($plan['rows'])) {
            return ['status' => 'empty', 'pool_id' => $poolId];
        }
        if ($dryRun) {
            return ['status' => 'dry_run', 'pool_id' => $poolId, 'plan' => $plan];
        }

        // exact-cent allocation keyed by county:pipe (sum === total_collected)
        $targets = [];
        foreach ($plan['rows'] as $r) {
            $key = ($r['county_id'] ?? 0) . ':' . $r['pipeline_code'];
            $targets[$key] = ($targets[$key] ?? 0) + $r['basis_amount'];
        }
        $amounts = RemainderAllocator::allocate((float) $pool->total_collected, $targets);

        DB::transaction(function () use ($poolId, $targets, $amounts) {
            // in-transaction idempotency guard (race-safe double-submit)
            $existing = DB::table('pool_distributions')->where('mother_pool_id', $poolId)->count();
            if ($existing > 0) return;
            foreach ($targets as $key => $basis) {
                [$countyId, $pipe] = explode(':', $key);
                DB::table('pool_distributions')->insert([
                    'mother_pool_id' => $poolId,
                    'beneficiary_type' => 'county_pipeline',
                    'beneficiary_id' => (int) $countyId,
                    'amount' => $amounts[$key],
                    'basis' => 'contribution_x_quality|' . $pipe,
                    'status' => 'settled',
                    'created_at' => now(), 'updated_at' => now(),
                ]);
            }
            DB::table('mother_pools')->where('id', $poolId)->update([
                'distribution_status' => 'settled', 'distributed_at' => now(), 'updated_at' => now(),
            ]);
        });

        return [
            'status' => 'settled',
            'pool_id' => $poolId,
            'total_distributed' => round(array_sum($amounts), 2),
            'rows' => $amounts,
        ];
    }

    /** @deprecated use settlePool() — kept for backward compatibility */
    public function distribute(int $poolId): void
    {
        $this->settlePool($poolId, false);
    }
}
