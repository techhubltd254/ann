<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Activates pipelines per tenant for every subsector that is NOT earning-locked
 * and is phase 1 (no external blocker). Licence-gated / blocked subsectors are
 * intentionally left unactivated — their regulators have not cleared.
 */
class PipelineActivationSeeder extends Seeder
{
    public function run(): void
    {
        $entries = config('kicc.subsectors', require config_path('kicc/subsectors/index.php'));
        $activatable = [];

        foreach ($entries as $e) {
            $locked = in_array($e['status'], ['licence_gated', 'blocked'], true)
                || !empty($e['engine']['ledger']['earning_locked']);
            if (!$locked && $e['phase'] === '1') {
                $activatable[] = $e['code'];
            }
        }

        // engine-quadrant counties get the full unlocked set
        $engineTenants = DB::table('tenants')->where('quadrant', 'engine')->pluck('id');
        $rows = 0;
        foreach ($engineTenants as $tenantId) {
            foreach ($activatable as $code) {
                $inserted = DB::table('pipelines')->updateOrInsert(
                    ['tenant_id' => $tenantId, 'subsector_code' => $code],
                    [
                        'status' => 'active',
                        'config' => json_encode(['activated_by' => 'PipelineActivationSeeder']),
                        'activated_at' => now(),
                        'updated_at' => now(),
                    ]
                );
                $rows += (int) $inserted;
            }
        }

        $this->command->info('PipelineActivationSeeder: ' . count($activatable)
            . ' unlocked phase-1 subsectors across ' . count($engineTenants) . ' engine tenants.');
    }
}
