<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            SubsectorRegistrySeeder::class,   // all 152 subsector pipeline registry rows
            TenantSeeder::class,              // sample tenants (shard key + quadrants)
            PipelineActivationSeeder::class,  // activations for unlocked phase-1 subsectors
        ]);
    }
}
