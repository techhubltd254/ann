<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Sample tenants across quadrants — demonstrates the shard-routing key
 * (tenant_id) and RPS/FNS quadrant assignment from the sharding plan.
 */
class TenantSeeder extends Seeder
{
    public function run(): void
    {
        $tenants = [
            ['name' => 'KICC Nairobi Hub', 'type' => 'county', 'county_id' => 1, 'quadrant' => 'engine'],
            ['name' => 'Mombasa Coastal Trade', 'type' => 'county', 'county_id' => 2, 'quadrant' => 'engine'],
            ['name' => 'Turkana Anchor Pilot', 'type' => 'county', 'county_id' => 15, 'quadrant' => 'anchor'],
            ['name' => 'Safari Curators Ltd', 'type' => 'enterprise', 'county_id' => 1, 'quadrant' => 'growth'],
        ];

        foreach ($tenants as $t) {
            $exists = DB::table('tenants')->where('name', $t['name'])->exists();
            if (!$exists) {
                DB::table('tenants')->insert($t + [
                    'status' => 'active',
                    'meta' => json_encode(['source' => 'TenantSeeder']),
                    'created_at' => now(), 'updated_at' => now(),
                ]);
            }
        }
    }
}
