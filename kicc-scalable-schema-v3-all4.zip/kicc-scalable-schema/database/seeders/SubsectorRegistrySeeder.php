<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Seeds the subsectors reference table with all 152 pipeline entries
 * from config('kicc.subsectors') (falls back to the bundled config file).
 * Idempotent: updateOrInsert on code.
 */
class SubsectorRegistrySeeder extends Seeder
{
    public function run(): void
    {
        $entries = config('kicc.subsectors', require config_path('kicc/subsectors/index.php'));

        foreach ($entries as $entry) {
            $locked = in_array($entry['status'], ['licence_gated', 'blocked'], true)
                || !empty($entry['engine']['ledger']['earning_locked']);

            DB::table('subsectors')->updateOrInsert(
                ['code' => $entry['code']],
                [
                    'parent' => $entry['parent'],
                    'sector' => $entry['sector'],
                    'subsector' => $entry['subsector'],
                    'slug' => $entry['slug'],
                    'phase' => $entry['phase'],
                    'status' => $entry['status'],
                    'economics' => json_encode($entry['economics']),
                    'regulators' => json_encode($entry['regulators']),
                    'tables' => json_encode($entry['tables']),
                    'kill_criteria' => json_encode($entry['kill_criteria']),
                    'earning_locked' => $locked,
                    'updated_at' => now(),
                ]
            );
        }

        $this->command->info('SubsectorRegistrySeeder: ' . count($entries) . ' subsector entries synced.');
    }
}
