<?php

/*
|--------------------------------------------------------------------------
| Sync the 152-subsector registry (config-driven, idempotent)
|--------------------------------------------------------------------------
| One migration for ALL 152 subsector pipelines — not 152 classes.
| Loops config('kicc.subsectors') and updateOrInsert()s every entry into the
| subsectors reference table. Safe to re-run; never deletes.
*/

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (!DB::getSchemaBuilder()->hasTable('subsectors')) {
            return; // core schema migration must run first
        }

        foreach (config('kicc.subsectors', require __DIR__ . '/../../config/kicc/subsectors/index.php') as $entry) {
            $locked = in_array($entry['status'], ['licence_gated', 'blocked'], true)
                || !empty($entry['engine']['ledger']['earning_locked']);

            DB::table('subsectors')->updateOrInsert(
                ['code' => $entry['code']],
                [
                    'parent' => $entry['parent'],
                    'sector' => $entry['sector'],
                    'subsector' => $entry['subsector'],
                    'slug' => $entry['slug'],
                    'phase' => $entry['phase'],
                    'status' => $entry['status'],
                    'economics' => json_encode($entry['economics']),
                    'regulators' => json_encode($entry['regulators']),
                    'tables' => json_encode($entry['tables']),
                    'kill_criteria' => json_encode($entry['kill_criteria']),
                    'earning_locked' => $locked,
                    'updated_at' => now(),
                ]
            );
        }
    }

    public function down(): void
    {
        // Reference data is never destroyed by a rollback.
    }
};
