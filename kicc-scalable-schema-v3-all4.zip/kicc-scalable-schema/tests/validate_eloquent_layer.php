<?php

/**
 * Framework-free validation of the generated Eloquent layer (exit 0 = valid).
 * Checks: 152 models, unique codes, class map completeness, earning-lock
 * consistency with status, and code agreement with the seed SQL.
 * Run: php tests/validate_eloquent_layer.php
 */

$fail = 0; $checks = 0;
$t = function (string $name, bool $cond) use (&$fail, &$checks) {
    $checks++;
    echo ($cond ? 'PASS' : 'FAIL') . "  {$name}\n";
    if (!$cond) $fail++;
};

$base   = dirname(__DIR__);
$modelDir = $base . '/app/Models/Subsectors';
$map    = require $base . '/config/kicc-eloquent-map.php';

// --- 1. scan every concrete model file ---------------------------------
$models = [];
$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($modelDir));
foreach ($rii as $file) {
    if ($file->isDir() || $file->getExtension() !== 'php') continue;
    if (basename($file->getFilename()) === 'AbstractSubsectorPipeline.php') continue;
    $src = file_get_contents($file->getPathname());
    preg_match("/const SUBSECTOR_CODE = '([^']+)'/", $src, $mCode);
    preg_match("/const STATUS = '([^']+)'/", $src, $mStatus);
    preg_match("/const EARNING_LOCKED = (true|false)/", $src, $mLock);
    preg_match("/namespace ([^;]+);/", $src, $mNs);
    preg_match("/class (\w+) extends/", $src, $mCls);
    if (!isset($mCode[1])) continue; // abstract base has empty const, already skipped
    $fqcn = ($mNs[1] ?? '') . '\\' . ($mCls[1] ?? '');
    $models[$mCode[1]] = [
        'status' => $mStatus[1] ?? '?',
        'locked' => ($mLock[1] ?? 'false') === 'true',
        'fqcn'   => $fqcn,
        'file'   => $file->getPathname(),
    ];
}

$t('model count == 152 (actual: ' . count($models) . ')', count($models) === 152);
$t('all SUBSECTOR_CODE values unique', count($models) === count(array_keys($models)));

// --- 2. map completeness + agreement ------------------------------------
$t('eloquent map covers exactly the 152 model codes',
   count(array_diff(array_keys($map), array_keys($models))) === 0
   && count(array_diff(array_keys($models), array_keys($map))) === 0);

$fqcnMismatch = [];
foreach ($models as $code => $info) {
    if (!isset($map[$code]) || ltrim($map[$code], '\\') !== ltrim($info['fqcn'], '\\')) {
        $fqcnMismatch[] = $code;
    }
}
$t('map FQCNs match model namespaces+classes (no mismatches)', empty($fqcnMismatch));

// --- 3. earning-lock consistency: locked iff status is gated/blocked -----
$lockBad = [];
foreach ($models as $code => $info) {
    $shouldBeLocked = in_array($info['status'], ['licence_gated', 'blocked'], true);
    if ($info['locked'] !== $shouldBeLocked) $lockBad[] = $code;
}
$t('EARNING_LOCKED consistent with STATUS across all 152 (bad: ' . count($lockBad) . ')', empty($lockBad));

// --- 4. codes agree with the seed SQL (registry of record) ---------------
$seed = file_get_contents($base . '/sql/seed_subsectors.sql');
preg_match_all("/'([A-Z]{1,2}\d+\.\d+)'/", $seed, $mSeed);
$seedCodes = $mSeed[1];
$t('seed SQL contains 152 rows (actual: ' . count($seedCodes) . ')', count($seedCodes) === 152);
$t('model codes == seed codes (no diff either direction)',
   empty(array_diff($seedCodes, array_keys($models))) && empty(array_diff(array_keys($models), $seedCodes)));

echo $fail === 0
    ? "\nELOQUENT LAYER VALID — {$checks} checks over " . count($models) . " models\n"
    : "\nELOQUENT LAYER INVALID — {$fail} of {$checks} checks failed\n";
exit($fail === 0 ? 0 : 1);
