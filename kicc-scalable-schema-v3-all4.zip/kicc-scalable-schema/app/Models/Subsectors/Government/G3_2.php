<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * County e-services — code G3.2
 * Sector: government · parent G3 · phase 2 · status absent
 * Economics: rate_note: KES 50-100 convenience fee
 * Earning locked: false
 */
class G3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G3.2';
    public const PARENT = 'G3';
    public const SECTOR = 'government';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
