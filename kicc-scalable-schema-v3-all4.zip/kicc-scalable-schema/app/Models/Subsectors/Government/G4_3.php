<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Data API access — code G4.3
 * Sector: government · parent G4 · phase 1 · status absent
 * Economics: rate_note: subscription/API
 * Earning locked: false
 */
class G4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G4.3';
    public const PARENT = 'G4';
    public const SECTOR = 'government';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
