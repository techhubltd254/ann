<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Business permits — code G1.1
 * Sector: government · parent G1 · phase 1 · status absent
 * Economics: commission, take_rate_pct [1.5, 2]
 * Earning locked: false
 */
class G1_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G1.1';
    public const PARENT = 'G1';
    public const SECTOR = 'government';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
