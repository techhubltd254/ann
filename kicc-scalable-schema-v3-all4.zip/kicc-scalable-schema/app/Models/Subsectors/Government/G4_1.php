<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Market reports — code G4.1
 * Sector: government · parent G4 · phase 1 · status absent
 * Economics: rate_note: subscription
 * Earning locked: false
 */
class G4_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G4.1';
    public const PARENT = 'G4';
    public const SECTOR = 'government';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
