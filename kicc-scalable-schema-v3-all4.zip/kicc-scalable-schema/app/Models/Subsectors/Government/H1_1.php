<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * National tenders escrow — code H1.1
 * Sector: government · parent H1 · phase 3 · status licence_gated
 * Economics: commission, take_rate_pct [0.5, 1]
 * Earning locked: true
 */
class H1_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'H1.1';
    public const PARENT = 'H1';
    public const SECTOR = 'government';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
