<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Licensing facilitation — code G3.3
 * Sector: government · parent G3 · phase 2 · status absent
 * Economics: rate_note: KES 50-100 convenience fee
 * Earning locked: false
 */
class G3_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G3.3';
    public const PARENT = 'G3';
    public const SECTOR = 'government';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
