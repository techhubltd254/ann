<?php

namespace App\Models\Subsectors\Government;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * County tenders escrow — code G2.1
 * Sector: government · parent G2 · phase 3 · status licence_gated
 * Economics: commission, take_rate_pct [0.5, 1]
 * Earning locked: true
 */
class G2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'G2.1';
    public const PARENT = 'G2';
    public const SECTOR = 'government';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
