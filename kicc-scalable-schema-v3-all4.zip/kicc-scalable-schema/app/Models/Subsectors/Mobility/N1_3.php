<?php

namespace App\Models\Subsectors\Mobility;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Insurance & parts commissions — code N1.3
 * Sector: mobility · parent N1 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class N1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'N1.3';
    public const PARENT = 'N1';
    public const SECTOR = 'mobility';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
