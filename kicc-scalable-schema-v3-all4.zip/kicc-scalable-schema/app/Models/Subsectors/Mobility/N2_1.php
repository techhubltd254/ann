<?php

namespace App\Models\Subsectors\Mobility;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Long-haul loads — code N2.1
 * Sector: mobility · parent N2 · phase 1 · status absent
 * Economics: commission, take_rate_pct [5, 10]
 * Earning locked: false
 */
class N2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'N2.1';
    public const PARENT = 'N2';
    public const SECTOR = 'mobility';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
