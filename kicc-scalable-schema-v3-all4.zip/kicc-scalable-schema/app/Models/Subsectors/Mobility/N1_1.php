<?php

namespace App\Models\Subsectors\Mobility;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Matatu SACCO collections — code N1.1
 * Sector: mobility · parent N1 · phase 2 · status absent
 * Economics: commission, take_rate_pct [0.5, 1]
 * Earning locked: false
 */
class N1_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'N1.1';
    public const PARENT = 'N1';
    public const SECTOR = 'mobility';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
