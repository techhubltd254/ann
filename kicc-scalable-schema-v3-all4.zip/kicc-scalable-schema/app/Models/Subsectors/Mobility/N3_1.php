<?php

namespace App\Models\Subsectors\Mobility;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Fleet fuel — code N3.1
 * Sector: mobility · parent N3 · phase 2 · status absent
 * Economics: commission, take_rate_pct [1, 2]
 * Earning locked: false
 */
class N3_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'N3.1';
    public const PARENT = 'N3';
    public const SECTOR = 'mobility';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
