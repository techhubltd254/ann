<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Coastal marine fisheries — code B4.2
 * Sector: agriculture · parent B4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B4_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B4.2';
    public const PARENT = 'B4';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
