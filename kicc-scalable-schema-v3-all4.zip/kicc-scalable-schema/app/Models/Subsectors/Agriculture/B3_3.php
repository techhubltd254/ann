<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Poultry — code B3.3
 * Sector: agriculture · parent B3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B3_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B3.3';
    public const PARENT = 'B3';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
