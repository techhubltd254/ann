<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Vegetables — EU desks — code B5.1
 * Sector: agriculture · parent B5 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class B5_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B5.1';
    public const PARENT = 'B5';
    public const SECTOR = 'agriculture';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
