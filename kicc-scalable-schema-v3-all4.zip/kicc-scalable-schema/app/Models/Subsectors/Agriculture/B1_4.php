<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Pulses & oilseeds — code B1.4
 * Sector: agriculture · parent B1 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B1_4 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B1.4';
    public const PARENT = 'B1';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
