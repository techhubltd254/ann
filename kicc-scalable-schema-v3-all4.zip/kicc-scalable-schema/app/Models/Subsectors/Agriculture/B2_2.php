<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Coffee union lots — code B2.2
 * Sector: agriculture · parent B2 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B2_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B2.2';
    public const PARENT = 'B2';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
