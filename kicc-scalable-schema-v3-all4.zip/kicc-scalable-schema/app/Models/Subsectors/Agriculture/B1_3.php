<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Coffee & tea lots — code B1.3
 * Sector: agriculture · parent B1 · phase 1 · status absent
 * Economics: commission, take_rate_pct [4, 5]
 * Earning locked: false
 */
class B1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B1.3';
    public const PARENT = 'B1';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
