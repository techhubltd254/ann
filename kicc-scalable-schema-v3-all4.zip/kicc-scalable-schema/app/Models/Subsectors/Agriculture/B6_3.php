<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Small equipment advances — code B6.3
 * Sector: agriculture · parent B6 · phase 3 · status licence_gated
 * Economics: rate_note: 2-3%/month, CBK-gated
 * Earning locked: true
 */
class B6_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B6.3';
    public const PARENT = 'B6';
    public const SECTOR = 'agriculture';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
