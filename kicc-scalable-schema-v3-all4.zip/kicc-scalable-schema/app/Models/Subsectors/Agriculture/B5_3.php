<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Cut flowers — code B5.3
 * Sector: agriculture · parent B5 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class B5_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B5.3';
    public const PARENT = 'B5';
    public const SECTOR = 'agriculture';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
