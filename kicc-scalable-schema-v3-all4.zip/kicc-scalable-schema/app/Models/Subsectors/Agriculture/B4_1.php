<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Lake Victoria fisheries — code B4.1
 * Sector: agriculture · parent B4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B4_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B4.1';
    public const PARENT = 'B4';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
