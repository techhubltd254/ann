<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Hides & leather — code B3.4
 * Sector: agriculture · parent B3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [4, 5]
 * Earning locked: false
 */
class B3_4 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B3.4';
    public const PARENT = 'B3';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
