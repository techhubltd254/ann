<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Certified seed advances — code B6.2
 * Sector: agriculture · parent B6 · phase 3 · status licence_gated
 * Economics: rate_note: 2-3%/month, CBK-gated
 * Earning locked: true
 */
class B6_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B6.2';
    public const PARENT = 'B6';
    public const SECTOR = 'agriculture';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
