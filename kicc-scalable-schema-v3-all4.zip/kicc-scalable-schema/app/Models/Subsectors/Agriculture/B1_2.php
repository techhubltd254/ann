<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Horticulture lots — code B1.2
 * Sector: agriculture · parent B1 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B1.2';
    public const PARENT = 'B1';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
