<?php

namespace App\Models\Subsectors\Agriculture;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Cattle trade — code B3.1
 * Sector: agriculture · parent B3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class B3_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'B3.1';
    public const PARENT = 'B3';
    public const SECTOR = 'agriculture';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
