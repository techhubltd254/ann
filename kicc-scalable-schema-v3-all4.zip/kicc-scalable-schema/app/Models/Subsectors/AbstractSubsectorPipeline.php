<?php

namespace App\Models\Subsectors;

use App\Support\TenantConnectionResolver;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * Shared base for all 152 subsector pipeline models.
 *
 * All models map onto the polymorphic partitioned core (`orders`) and are
 * scoped to their subsector_code — no per-subsector tables, per the sharding
 * plan (SCHEMA_SHARDING.md): shard key is tenant_id, NOT subsector_code.
 */
abstract class AbstractSubsectorPipeline extends Model
{
    public const SUBSECTOR_CODE = '';
    public const PARENT = '';
    public const SECTOR = '';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;

    protected $table = 'orders';

    protected $fillable = [
        'tenant_id', 'subsector_code', 'county_id',
        'gmv', 'fee', 'status', 'meta',
    ];

    protected $casts = [
        'gmv' => 'decimal:2',
        'fee' => 'decimal:2',
        'meta' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        // every read/write on this model is scoped to its own subsector
        static::addGlobalScope('subsector', function (Builder $builder) {
            $builder->where('subsector_code', static::SUBSECTOR_CODE);
        });

        static::creating(function (self $model) {
            $model->subsector_code = static::SUBSECTOR_CODE;
        });
    }

    /**
     * Instance bound to a tenant's shard connection (Level-3 routing;
     * dormant until config('kicc-sharding.tenant_map') is populated).
     */
    public static function forTenant(int $tenantId): self
    {
        $model = new static();
        $model->setConnection(TenantConnectionResolver::forTenant($tenantId));
        $model->tenant_id = $tenantId;
        return $model;
    }

    /** Mother-Pool / joiner reads always use the primary connection. */
    public static function onPrimary(): self
    {
        $model = new static();
        $model->setConnection(TenantConnectionResolver::forMotherPool());
        return $model;
    }
    /** Registry row for this subsector (from the subsectors reference table). */
    public static function registry(): ?array
    {
        $row = DB::table('subsectors')->where('code', static::SUBSECTOR_CODE)->first();
        return $row ? (array) $row : null;
    }

    /** Builder without the subsector scope (escape hatch for cross-pipeline queries). */
    public static function queryAllSubsectors(): Builder
    {
        return (new static())->newQueryWithoutScopes();
    }
}
