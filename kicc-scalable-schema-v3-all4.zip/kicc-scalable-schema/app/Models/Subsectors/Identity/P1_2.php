<?php

namespace App\Models\Subsectors\Identity;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Individual KYC checks — code P1.2
 * Sector: identity · parent P1 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class P1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'P1.2';
    public const PARENT = 'P1';
    public const SECTOR = 'identity';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
