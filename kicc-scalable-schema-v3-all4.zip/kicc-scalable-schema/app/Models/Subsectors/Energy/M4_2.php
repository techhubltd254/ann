<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * E-waste exchange — code M4.2
 * Sector: energy · parent M4 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class M4_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M4.2';
    public const PARENT = 'M4';
    public const SECTOR = 'energy';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
