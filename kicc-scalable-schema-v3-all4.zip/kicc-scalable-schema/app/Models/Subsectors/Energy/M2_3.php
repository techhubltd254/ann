<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Verification brokerage — code M2.3
 * Sector: energy · parent M2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class M2_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M2.3';
    public const PARENT = 'M2';
    public const SECTOR = 'energy';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
