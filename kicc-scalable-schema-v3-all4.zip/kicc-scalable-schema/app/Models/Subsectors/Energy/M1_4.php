<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Installer referrals — code M1.4
 * Sector: energy · parent M1 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class M1_4 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M1.4';
    public const PARENT = 'M1';
    public const SECTOR = 'energy';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
