<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Water kiosks — code M3.2
 * Sector: energy · parent M3 · phase 2 · status absent
 * Economics: commission, take_rate_pct [0.5, 1]
 * Earning locked: false
 */
class M3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M3.2';
    public const PARENT = 'M3';
    public const SECTOR = 'energy';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
