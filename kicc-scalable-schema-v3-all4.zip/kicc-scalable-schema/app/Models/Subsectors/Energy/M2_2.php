<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Forestry credits — code M2.2
 * Sector: energy · parent M2 · phase 2 · status absent
 * Economics: commission, take_rate_pct [10, 15]
 * Earning locked: false
 */
class M2_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M2.2';
    public const PARENT = 'M2';
    public const SECTOR = 'energy';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
