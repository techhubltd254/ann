<?php

namespace App\Models\Subsectors\Energy;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * PAYG solar escrow — code M1.2
 * Sector: energy · parent M1 · phase 2 · status absent
 * Economics: commission, take_rate_pct [5, 10]
 * Earning locked: false
 */
class M1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'M1.2';
    public const PARENT = 'M1';
    public const SECTOR = 'energy';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
