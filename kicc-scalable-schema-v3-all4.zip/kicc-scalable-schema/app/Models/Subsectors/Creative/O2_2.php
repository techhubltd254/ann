<?php

namespace App\Models\Subsectors\Creative;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Athletics management — code O2.2
 * Sector: creative · parent O2 · phase 3 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class O2_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'O2.2';
    public const PARENT = 'O2';
    public const SECTOR = 'creative';
    public const PHASE = '3';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
