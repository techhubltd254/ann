<?php

namespace App\Models\Subsectors\Creative;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Paid event streaming — code O1.3
 * Sector: creative · parent O1 · phase 1 · status partial
 * Economics: commission, take_rate_pct [10, 15]
 * Earning locked: false
 */
class O1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'O1.3';
    public const PARENT = 'O1';
    public const SECTOR = 'creative';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
