<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * IP licensing exchange — code L4.3
 * Sector: education · parent L4 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class L4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L4.3';
    public const PARENT = 'L4';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
