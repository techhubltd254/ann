<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Transport fee rails — code L3.3
 * Sector: education · parent L3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [0.5, 1]
 * Earning locked: false
 */
class L3_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L3.3';
    public const PARENT = 'L3';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
