<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * ICT lab kits — code L5.3
 * Sector: education · parent L5 · phase 1 · status absent
 * Economics: commission, take_rate_pct [2, 4]
 * Earning locked: false
 */
class L5_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L5.3';
    public const PARENT = 'L5';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
