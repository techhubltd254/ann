<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Internships — code L4.1
 * Sector: education · parent L4 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class L4_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L4.1';
    public const PARENT = 'L4';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
