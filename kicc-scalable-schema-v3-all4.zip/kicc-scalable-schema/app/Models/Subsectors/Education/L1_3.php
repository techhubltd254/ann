<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Certification revenue share — code L1.3
 * Sector: education · parent L1 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class L1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L1.3';
    public const PARENT = 'L1';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
