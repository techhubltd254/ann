<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Apprenticeship matching — code L1.2
 * Sector: education · parent L1 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class L1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L1.2';
    public const PARENT = 'L1';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
