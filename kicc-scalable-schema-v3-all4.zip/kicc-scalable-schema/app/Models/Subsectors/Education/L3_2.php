<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Education supplies — code L3.2
 * Sector: education · parent L3 · phase 1 · status absent
 * Economics: rate_note: margin
 * Earning locked: false
 */
class L3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L3.2';
    public const PARENT = 'L3';
    public const SECTOR = 'education';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
