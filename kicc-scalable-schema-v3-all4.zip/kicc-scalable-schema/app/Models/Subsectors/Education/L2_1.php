<?php

namespace App\Models\Subsectors\Education;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Gulf corridor verification — code L2.1
 * Sector: education · parent L2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class L2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'L2.1';
    public const PARENT = 'L2';
    public const SECTOR = 'education';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
