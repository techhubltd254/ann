<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Season input advances — code F3.1
 * Sector: financing · parent F3 · phase 3 · status licence_gated
 * Economics: rate_note: harvest recovery, CBK-gated
 * Earning locked: true
 */
class F3_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F3.1';
    public const PARENT = 'F3';
    public const SECTOR = 'financing';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
