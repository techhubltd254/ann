<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Treasury parking — code F5.2
 * Sector: financing · parent F5 · phase 3 · status licence_gated
 * Economics: rate_note: CBK-gated
 * Earning locked: true
 */
class F5_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F5.2';
    public const PARENT = 'F5';
    public const SECTOR = 'financing';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
