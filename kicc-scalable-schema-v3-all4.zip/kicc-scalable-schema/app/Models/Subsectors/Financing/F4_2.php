<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * KYB API checks — code F4.2
 * Sector: financing · parent F4 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class F4_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F4.2';
    public const PARENT = 'F4';
    public const SECTOR = 'financing';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
