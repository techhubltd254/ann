<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Trade treasury — code F1.2
 * Sector: financing · parent F1 · phase 3 · status licence_gated
 * Economics: rate_note: 2-3%/month, CBK-gated
 * Earning locked: true
 */
class F1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F1.2';
    public const PARENT = 'F1';
    public const SECTOR = 'financing';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
