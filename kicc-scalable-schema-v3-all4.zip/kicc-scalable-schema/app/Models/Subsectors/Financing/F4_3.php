<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Device & asset insurance — code F4.3
 * Sector: financing · parent F4 · phase 2 · status absent
 * Economics: commission, take_rate_pct [10, 20]
 * Earning locked: false
 */
class F4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F4.3';
    public const PARENT = 'F4';
    public const SECTOR = 'financing';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
