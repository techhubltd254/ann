<?php

namespace App\Models\Subsectors\Financing;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Escrow float — code F5.1
 * Sector: financing · parent F5 · phase 3 · status licence_gated
 * Economics: rate_note: KES 0 until CBK confirms
 * Earning locked: true
 */
class F5_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'F5.1';
    public const PARENT = 'F5';
    public const SECTOR = 'financing';
    public const PHASE = '3';
    public const STATUS = 'licence_gated';
    public const EARNING_LOCKED = true;
}
