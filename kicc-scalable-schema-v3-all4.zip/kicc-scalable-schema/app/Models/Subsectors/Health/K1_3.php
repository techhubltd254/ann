<?php

namespace App\Models\Subsectors\Health;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Lab equipment — code K1.3
 * Sector: health · parent K1 · phase 2 · status absent
 * Economics: commission, take_rate_pct [1.5, 3]
 * Earning locked: false
 */
class K1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'K1.3';
    public const PARENT = 'K1';
    public const SECTOR = 'health';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
