<?php

namespace App\Models\Subsectors\Health;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Health data analytics — code K3.2
 * Sector: health · parent K3 · phase 2 · status blocked
 * Economics: rate_note: BLOCKED
 * Earning locked: true
 */
class K3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'K3.2';
    public const PARENT = 'K3';
    public const SECTOR = 'health';
    public const PHASE = '2';
    public const STATUS = 'blocked';
    public const EARNING_LOCKED = true;
}
