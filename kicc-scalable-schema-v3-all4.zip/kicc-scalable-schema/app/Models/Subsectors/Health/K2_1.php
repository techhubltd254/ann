<?php

namespace App\Models\Subsectors\Health;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Clinic SaaS — code K2.1
 * Sector: health · parent K2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class K2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'K2.1';
    public const PARENT = 'K2';
    public const SECTOR = 'health';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
