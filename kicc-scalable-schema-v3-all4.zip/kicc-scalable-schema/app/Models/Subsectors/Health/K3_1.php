<?php

namespace App\Models\Subsectors\Health;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Teleconsultation — code K3.1
 * Sector: health · parent K3 · phase 2 · status blocked
 * Economics: rate_note: BLOCKED — Digital Health Act struck down
 * Earning locked: true
 */
class K3_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'K3.1';
    public const PARENT = 'K3';
    public const SECTOR = 'health';
    public const PHASE = '2';
    public const STATUS = 'blocked';
    public const EARNING_LOCKED = true;
}
