<?php

namespace App\Models\Subsectors\Health;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Hospital HIS — code K2.2
 * Sector: health · parent K2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class K2_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'K2.2';
    public const PARENT = 'K2';
    public const SECTOR = 'health';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
