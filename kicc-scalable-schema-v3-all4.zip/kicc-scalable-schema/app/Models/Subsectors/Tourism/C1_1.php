<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Attractions & parks — code C1.1
 * Sector: tourism · parent C1 · phase 1 · status partial
 * Economics: commission, take_rate_pct [15, 18]
 * Earning locked: false
 */
class C1_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C1.1';
    public const PARENT = 'C1';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
