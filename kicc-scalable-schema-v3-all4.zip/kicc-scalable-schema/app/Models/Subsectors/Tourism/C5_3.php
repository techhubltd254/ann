<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Wedding & event venues — code C5.3
 * Sector: tourism · parent C5 · phase 1 · status partial
 * Economics: rate_note: booking fee
 * Earning locked: false
 */
class C5_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C5.3';
    public const PARENT = 'C5';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
