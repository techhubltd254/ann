<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Conference venues — code C5.1
 * Sector: tourism · parent C5 · phase 1 · status partial
 * Economics: rate_note: booking fee + dynamic pricing
 * Earning locked: false
 */
class C5_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C5.1';
    public const PARENT = 'C5';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
