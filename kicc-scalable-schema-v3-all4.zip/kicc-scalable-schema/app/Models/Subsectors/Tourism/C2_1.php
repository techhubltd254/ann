<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Leisure itineraries — code C2.1
 * Sector: tourism · parent C2 · phase 1 · status partial
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class C2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C2.1';
    public const PARENT = 'C2';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
