<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * County homestays — code C4.1
 * Sector: tourism · parent C4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [13, 15]
 * Earning locked: false
 */
class C4_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C4.1';
    public const PARENT = 'C4';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
