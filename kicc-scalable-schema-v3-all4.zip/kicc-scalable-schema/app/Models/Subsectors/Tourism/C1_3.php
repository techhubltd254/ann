<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Day tours — code C1.3
 * Sector: tourism · parent C1 · phase 1 · status partial
 * Economics: commission, take_rate_pct [15, 18]
 * Earning locked: false
 */
class C1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C1.3';
    public const PARENT = 'C1';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
