<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Cultural experiences — code C4.3
 * Sector: tourism · parent C4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [15, 20]
 * Earning locked: false
 */
class C4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C4.3';
    public const PARENT = 'C4';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
