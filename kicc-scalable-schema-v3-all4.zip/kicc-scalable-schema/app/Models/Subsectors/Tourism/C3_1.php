<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Safari packages (MoR) — code C3.1
 * Sector: tourism · parent C3 · phase 2 · status absent
 * Economics: commission, take_rate_pct [20, 30]
 * Earning locked: false
 */
class C3_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C3.1';
    public const PARENT = 'C3';
    public const SECTOR = 'tourism';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
