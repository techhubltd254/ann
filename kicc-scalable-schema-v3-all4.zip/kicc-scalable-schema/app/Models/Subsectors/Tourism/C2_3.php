<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * MICE travel itineraries — code C2.3
 * Sector: tourism · parent C2 · phase 1 · status partial
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class C2_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C2.3';
    public const PARENT = 'C2';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
