<?php

namespace App\Models\Subsectors\Tourism;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Exhibition booths — code C5.2
 * Sector: tourism · parent C5 · phase 1 · status partial
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class C5_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'C5.2';
    public const PARENT = 'C5';
    public const SECTOR = 'tourism';
    public const PHASE = '1';
    public const STATUS = 'partial';
    public const EARNING_LOCKED = false;
}
