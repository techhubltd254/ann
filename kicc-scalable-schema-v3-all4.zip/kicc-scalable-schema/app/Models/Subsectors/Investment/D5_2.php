<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Industrial minerals — code D5.2
 * Sector: investment · parent D5 · phase 2 · status absent
 * Economics: commission, take_rate_pct [2, 5]
 * Earning locked: false
 */
class D5_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D5.2';
    public const PARENT = 'D5';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
