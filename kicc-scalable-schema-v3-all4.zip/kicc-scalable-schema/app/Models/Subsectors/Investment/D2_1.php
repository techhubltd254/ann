<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Skilled trades placement — code D2.1
 * Sector: investment · parent D2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class D2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D2.1';
    public const PARENT = 'D2';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
