<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * EPZ facilitation — code D1.3
 * Sector: investment · parent D1 · phase 2 · status absent
 * Economics: commission, take_rate_pct [0.1, 0.5]
 * Earning locked: false
 */
class D1_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D1.3';
    public const PARENT = 'D1';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
