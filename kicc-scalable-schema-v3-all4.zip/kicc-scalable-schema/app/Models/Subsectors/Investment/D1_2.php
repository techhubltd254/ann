<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Industrial park deals — code D1.2
 * Sector: investment · parent D1 · phase 2 · status absent
 * Economics: commission, take_rate_pct [0.1, 0.5]
 * Earning locked: false
 */
class D1_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D1.2';
    public const PARENT = 'D1';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
