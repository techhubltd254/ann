<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Gemstones & jewellery — code D5.1
 * Sector: investment · parent D5 · phase 2 · status absent
 * Economics: commission, take_rate_pct [3, 5]
 * Earning locked: false
 */
class D5_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D5.1';
    public const PARENT = 'D5';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
