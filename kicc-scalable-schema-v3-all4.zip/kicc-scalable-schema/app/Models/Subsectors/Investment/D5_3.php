<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Royalty-split facilitation — code D5.3
 * Sector: investment · parent D5 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class D5_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D5.3';
    public const PARENT = 'D5';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
