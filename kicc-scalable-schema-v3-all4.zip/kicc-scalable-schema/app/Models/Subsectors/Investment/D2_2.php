<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Engineer placement — code D2.2
 * Sector: investment · parent D2 · phase 2 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class D2_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D2.2';
    public const PARENT = 'D2';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
