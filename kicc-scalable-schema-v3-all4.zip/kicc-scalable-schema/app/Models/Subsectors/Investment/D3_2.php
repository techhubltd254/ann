<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Commercial leasing — code D3.2
 * Sector: investment · parent D3 · phase 2 · status blocked
 * Economics: commission, take_rate_pct [2, 5]
 * Earning locked: true
 */
class D3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D3.2';
    public const PARENT = 'D3';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'blocked';
    public const EARNING_LOCKED = true;
}
