<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Diaspora SME investment — code D4.3
 * Sector: investment · parent D4 · phase 2 · status absent
 * Economics: rate_note: commission
 * Earning locked: false
 */
class D4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D4.3';
    public const PARENT = 'D4';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
