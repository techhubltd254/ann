<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Diaspora real estate — code D4.1
 * Sector: investment · parent D4 · phase 2 · status absent
 * Economics: rate_note: FX spread + commission
 * Earning locked: false
 */
class D4_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D4.1';
    public const PARENT = 'D4';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
