<?php

namespace App\Models\Subsectors\Investment;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Diaspora SEZ participation — code D4.2
 * Sector: investment · parent D4 · phase 2 · status absent
 * Economics: rate_note: commission
 * Earning locked: false
 */
class D4_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'D4.2';
    public const PARENT = 'D4';
    public const SECTOR = 'investment';
    public const PHASE = '2';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
