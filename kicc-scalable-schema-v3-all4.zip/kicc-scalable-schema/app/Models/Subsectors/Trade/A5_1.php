<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Food & beverage franchises — code A5.1
 * Sector: trade · parent A5 · phase 1 · status absent
 * Economics: commission, take_rate_pct [1, 3]
 * Earning locked: false
 */
class A5_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A5.1';
    public const PARENT = 'A5';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
