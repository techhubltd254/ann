<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Finishes & fittings — code A3.3
 * Sector: trade · parent A3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [3, 4]
 * Earning locked: false
 */
class A3_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A3.3';
    public const PARENT = 'A3';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
