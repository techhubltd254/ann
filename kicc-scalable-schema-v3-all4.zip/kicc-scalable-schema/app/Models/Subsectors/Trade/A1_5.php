<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * B2B industrial supplies — code A1.5
 * Sector: trade · parent A1 · phase 1 · status built
 * Economics: commission, take_rate_pct [2, 4]
 * Earning locked: false
 */
class A1_5 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A1.5';
    public const PARENT = 'A1';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'built';
    public const EARNING_LOCKED = false;
}
