<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Auto dealerships — code A5.3
 * Sector: trade · parent A5 · phase 1 · status absent
 * Economics: commission, take_rate_pct [2, 3]
 * Earning locked: false
 */
class A5_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A5.3';
    public const PARENT = 'A5';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
