<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Exhibitor subscriptions & ads — code A1.6
 * Sector: trade · parent A1 · phase 1 · status built
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class A1_6 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A1.6';
    public const PARENT = 'A1';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'built';
    public const EARNING_LOCKED = false;
}
