<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * General merchandise — code A1.1
 * Sector: trade · parent A1 · phase 1 · status built
 * Economics: commission, take_rate_pct [2, 5]
 * Earning locked: false
 */
class A1_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A1.1';
    public const PARENT = 'A1';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'built';
    public const EARNING_LOCKED = false;
}
