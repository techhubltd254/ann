<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Bulk wholesale trade — code A4.2
 * Sector: trade · parent A4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [1, 2]
 * Earning locked: false
 */
class A4_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A4.2';
    public const PARENT = 'A4';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
