<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Retail business sales — code A6.1
 * Sector: trade · parent A6 · phase 3 · status absent
 * Economics: commission, take_rate_pct [1, 2]
 * Earning locked: false
 */
class A6_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A6.1';
    public const PARENT = 'A6';
    public const SECTOR = 'trade';
    public const PHASE = '3';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
