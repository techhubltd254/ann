<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Northern & EAC road corridors — code A2.3
 * Sector: trade · parent A2 · phase 1 · status absent
 * Economics: rate_note: landed-cost margin
 * Earning locked: false
 */
class A2_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A2.3';
    public const PARENT = 'A2';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
