<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Customs brokerage desk — code A2.4
 * Sector: trade · parent A2 · phase 1 · status absent
 * Economics: flat_fee, flat_fee_kes 0
 * Earning locked: false
 */
class A2_4 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A2.4';
    public const PARENT = 'A2';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
