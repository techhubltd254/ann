<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Roofing & iron sheets — code A3.2
 * Sector: trade · parent A3 · phase 1 · status absent
 * Economics: commission, take_rate_pct [2, 4]
 * Earning locked: false
 */
class A3_2 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A3.2';
    public const PARENT = 'A3';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
