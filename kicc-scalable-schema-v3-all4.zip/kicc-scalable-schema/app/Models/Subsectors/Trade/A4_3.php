<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Agrovet supply — code A4.3
 * Sector: trade · parent A4 · phase 1 · status absent
 * Economics: commission, take_rate_pct [2, 3]
 * Earning locked: false
 */
class A4_3 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A4.3';
    public const PARENT = 'A4';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
