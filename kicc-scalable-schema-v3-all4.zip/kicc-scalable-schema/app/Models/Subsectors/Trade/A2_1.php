<?php

namespace App\Models\Subsectors\Trade;

use App\Models\Subsectors\AbstractSubsectorPipeline;

/**
 * Sea freight consolidation — code A2.1
 * Sector: trade · parent A2 · phase 1 · status absent
 * Economics: rate_note: landed-cost margin + FX spread
 * Earning locked: false
 */
class A2_1 extends AbstractSubsectorPipeline
{
    public const SUBSECTOR_CODE = 'A2.1';
    public const PARENT = 'A2';
    public const SECTOR = 'trade';
    public const PHASE = '1';
    public const STATUS = 'absent';
    public const EARNING_LOCKED = false;
}
