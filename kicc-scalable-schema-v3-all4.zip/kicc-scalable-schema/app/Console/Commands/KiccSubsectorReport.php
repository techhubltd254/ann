<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * Coverage + drift report for the 152 subsector pipeline models.
 *
 *   php artisan kicc:subsector:report               # full table by sector
 *   php artisan kicc:subsector:report --sector=tourism
 *   php artisan kicc:subsector:report --locked      # only earning-locked
 *   php artisan kicc:subsector:report --drift       # registry vs model map vs DB
 *
 * Exit code FAILURE if drift is detected (missing/extra codes anywhere).
 */
class KiccSubsectorReport extends Command
{
    protected $signature = 'kicc:subsector:report {--sector=} {--locked} {--drift}';
    protected $description = 'Report subsector model coverage (152), earning-lock status, and registry/map/database drift';

    public function handle(): int
    {
        $map      = config('kicc-eloquent-map', []);
        $registry = config('kicc.subsectors', require config_path('kicc/subsectors/index.php'));

        $regCodes  = array_column($registry, 'code');
        $mapCodes  = array_keys($map);
        $missingInMap = array_diff($regCodes, $mapCodes);
        $extraInMap   = array_diff($mapCodes, $regCodes);

        $sectorFilter = $this->option('sector');
        $onlyLocked   = $this->option('locked');

        $rows = [];
        $lockedCount = 0;
        foreach ($registry as $entry) {
            $code = $entry['code'];
            if ($sectorFilter && $entry['sector'] !== $sectorFilter) continue;

            $locked = in_array($entry['status'], ['licence_gated', 'blocked'], true)
                || !empty($entry['engine']['ledger']['earning_locked']);
            if ($onlyLocked && !$locked) continue;
            $lockedCount += $locked ? 1 : 0;

            $rows[] = [
                $code,
                $entry['parent'],
                $entry['sector'],
                $entry['phase'],
                $entry['status'],
                $locked ? 'LOCKED' : 'open',
                isset($map[$code]) ? 'yes' : 'MISSING',
            ];
        }

        $this->info(sprintf('Registry: %d subsectors | model map: %d | locked: %d | open: %d',
            count($regCodes), count($mapCodes), $lockedCount, count($rows) - $lockedCount));
        $this->table(['code', 'parent', 'sector', 'phase', 'status', 'lock', 'model?'], $rows);

        $drift = !empty($missingInMap) || !empty($extraInMap);
        if ($drift || $this->option('drift')) {
            foreach ($missingInMap as $c) $this->error("DRIFT: registry code {$c} has NO model in kicc-eloquent-map");
            foreach ($extraInMap as $c)   $this->error("DRIFT: map entry {$c} is NOT in the registry");
            if (!$drift && $this->option('drift')) $this->info('No drift: registry, model map and configuration agree.');
        }

        // database cross-check (when the schema is deployed)
        try {
            $dbCount = DB::table('subsectors')->count();
            $this->line(sprintf('Database subsectors rows: %d %s', $dbCount,
                $dbCount === count($regCodes) ? '(matches registry)' : '<-- DRIFT vs registry'));
        } catch (\Throwable $e) {
            $this->line('Database cross-check skipped (schema not reachable): ' . $e->getMessage());
        }

        return $drift ? self::FAILURE : self::SUCCESS;
    }
}
